# Changelog

## 0.1.1 — final frozen NitroXAI package

- Packages the final Window-61 full-protein ESM-2 NitroXAI five-fold ensemble.
- Includes matching fold-specific handcrafted and ESM scaler bundles.
- Freezes the development-OOF threshold `0.5757167935371399`.
- Adds full-sequence, FASTA, UniProt, batch, CLI, and raw Integrated Gradients
  inference interfaces.
- Does not retrain, fine-tune ESM-2, refit scalers, optimize thresholds, or
  upload artifacts to PyPI.
