# NitroXAI 0.1.1 reproducibility report

## Authoritative environment

The final package was audited, tested, and built in Jupyter kernel **Python
(NitroXAI CV)** (`nitroxai_cv`):

- interpreter: `/home/sray/anaconda3/envs/nitroxai_cv/bin/python`
- Python 3.11.16, Linux x86_64
- PyTorch 2.13.0+cu130; CUDA build 13.0; CUDA available during validation on
  an NVIDIA GeForce RTX 4070 SUPER
- NumPy 2.4.6; pandas 3.0.5; scikit-learn 1.9.0; SciPy 1.17.1; joblib 1.5.3;
  Biopython 1.88; requests 2.34.2
- ESM import: `esm`; distribution: `fair-esm==2.0.0`, installed by pip with no
  Git/direct-URL metadata

The exact ESM loader is
`esm.pretrained.load_model_and_alphabet("esm2_t30_150M_UR50D")`.  It loads the
canonical cache-managed weights; those 150M pretrained weights are not copied
into the package archives.  The observed cached model SHA-256 is
`881c7176cf198ef8dec26a3c375d40eb58d0c33df95c22562ca6cc6d3f812c62`.

Full archival records are in:

- `reproducibility/environment_info.txt`
- `reproducibility/environment-nitroxai-cv.yml`
- `reproducibility/requirements-nitroxai-cv-freeze.txt`
- `reproducibility/validated_versions.txt`
- `reproducibility/esm_environment_info.txt`

## Frozen scientific artifacts

The source package contains only five final downstream fold checkpoints, five
matching fold scaler bundles, and immutable configuration/manifest JSON.  No
training data, independent-test data, raw ESM cache, notebook cache, or ESM
pretrained weights is bundled.  `reproducibility/artifact_manifest.csv`
records original paths, sizes, SHA-256 values, packaged destinations, and final
notebook usage for every included frozen artifact.

The existing workspace MIT license is carried unchanged as `LICENSE`.

## Verification summary

- `pytest -q`: **35 passed** in the authoritative environment.
- All five checkpoints strict-load with matching state tensors and have the
  final downstream parameter count of 195,970.
- Live full-protein ESM windows for three representative sites match final raw
  caches exactly on CUDA.
- Full independent-test downstream replay (10,138 sites): maximum fold and
  ensemble probability differences `0.0`; all classes and final published
  metrics reproduce exactly.  Machine-readable values are in
  `reproducibility/independent_test_package_replay.json`.
- Saved Integrated Gradients reference A8K7I4 C386: maximum signed and
  absolute positional difference `5.9604645e-08`; modality totals match
  exactly.
- A fresh temporary virtual environment installed the wheel outside the
  repository, passed `pip check`, and exercised CLI/API-related paths with the
  installed package.  Its P18669 C153 source-versus-wheel fold and ensemble
  probabilities were exactly equal on CUDA.

Details, tolerances, and the documented CPU backend floating-point note are in
`NOTEBOOK_PARITY_REPORT.md`; the complete source-of-truth audit is in
`AUDIT.md`.
