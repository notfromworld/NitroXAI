# NitroXAI 0.1.1 (10.5281/zenodo.22238589)

NitroXAI is an interpretable residue-level S-nitrosylation predictor that
integrates handcrafted biochemical descriptors with contextual ESM-2 protein
language-model representations.

It packages the frozen final model from
`NitroXAI_ESM61_FINAL_COMPLETE.ipynb`: no model retraining, ESM fine-tuning,
scaler refitting, threshold optimization, or model substitution occurs at
inference time.

## Important input rule

Give NitroXAI the **complete protein sequence**. Do not extract a 61-residue
window yourself. NitroXAI runs frozen ESM-2 on the full cleaned protein first,
then extracts a cysteine-centered contextual 61-residue representation. A
protein with several cysteines is embedded once and all downstream sites are
batched.

## Model

- Handcrafted input: 61 x 27
  - 20 amino-acid one-hot channels, hydropathy, acidic, basic, cysteine,
    proline, and two positional-distance channels.
- ESM input: 61 x 640 contextual representations.
  - Backbone: `esm2_t30_150M_UR50D`, loaded through `fair-esm==2.0.0`.
  - Representation: final layer 30, after full-protein encoding.
  - BOS/EOS are removed; out-of-protein ESM window positions are zero-padded
    before the final notebook's fold-specific scaling.
- Architecture: CNN-BiLSTM handcrafted encoder (128) plus one-layer learned
  attention-pooled ESM representation (640), concatenated to 768, then
  `768 -> 64 -> 1` raw logit.
- Backbone: frozen and in evaluation mode. Trainable downstream parameters:
  195,970.
- Ensemble: mean of five fold probabilities, not logits.
- Frozen decision threshold: `0.5757167935371399`.

The package intentionally does not bundle the 150M ESM weights. The validated
fair-esm loader uses its normal PyTorch cache and downloads the canonical
weights if permitted. If they cannot be found or retrieved, NitroXAI returns a
clear error instead of changing model behavior.

## Install

Install the locally built artifact; this release is not uploaded to PyPI.

```bash
pip install dist/nitroxai-0.1.1-py3-none-any.whl
```

`Python (NitroXAI CV)` is the authoritative environment. Its full export and
freeze are included under `reproducibility/`; pinned runtime dependencies are
listed in `pyproject.toml`.

## Command line

```bash
nitroxai --version
nitroxai info

nitroxai predict --uniprot P04637
nitroxai predict --fasta protein.fasta
nitroxai predict --sequence "M..."

nitroxai predict --uniprot P04637 --position 182
nitroxai predict --fasta protein.fasta --position 182

nitroxai batch --fasta proteins.fasta --output predictions.csv
nitroxai batch --accessions accessions.txt --output predictions.csv

nitroxai explain --uniprot P04637 --position 182 --output explanation.csv
nitroxai explain --uniprot P04637 --position 182 --attention --output explanation.json
```

Public positions are 1-based and must identify cysteine. `predict` scans every
cysteine unless `--position` is supplied. Output formats are `table`, `csv`,
and `json`; use `--fold-probabilities` for individual fold probabilities and
`--context` to include the 61-residue sequence window.

Every command writes to the terminal unless `--output FILE` is supplied. For
an output path ending in `.csv` or `.json`, the format is selected
automatically; `--format` can still be used to override it.

`--device auto` is the default. `--device cpu` is supported; `--device cuda`
requires an available CUDA device.

## Python API

```python
from nitroxai import NitroXAIPredictor

predictor = NitroXAIPredictor()

results = predictor.predict_sequence(full_sequence)
site = predictor.predict_site(full_sequence, position=182)
fasta_results = predictor.predict_fasta("protein.fasta")
uniprot_results = predictor.predict_uniprot("P04637")
explanation = predictor.explain_site(full_sequence, position=182)
```

`PredictionResult.to_dict()` gives stable tabular/JSON fields. Explanations
provide raw signed and absolute residue IG, per-position handcrafted and ESM
absolute IG, modality fractions, and optionally learned attention weights.
Attention is reported separately from Integrated Gradients.

## Interpretability

The final notebook does not use Captum. It implements manual, 32-step
right-Riemann Integrated Gradients against each fold's raw logit, with a zero
baseline in that fold's standardized input space. NitroXAI reproduces that
procedure and averages raw attributions across folds. Modality fractions use
the notebook definition: fold-mean `sum(abs(IG))` for each modality divided by
their sum. Raw attributions are not display-normalized.

## Sequence length behavior

The final human notebook used full-protein ESM encoding with no manual
truncation, manual 1022-residue rejection, or chunking. Its largest validated
human protein was 4,857 residues; a separate cross-species evaluation subset
used a 5,000-residue cohort cutoff, which is not a general inference fallback.
NitroXAI therefore attempts the exact full protocol and reports an informative
memory/runtime error if the validated loader cannot encode an input. It never
silently truncates, chunks, or embeds an isolated 61-residue fragment.

## Reproducibility

- [Notebook audit](AUDIT.md)
- [Notebook/package parity report](NOTEBOOK_PARITY_REPORT.md)
- [Reproducibility report](REPRODUCIBILITY_REPORT.md)
- [Artifact manifest](reproducibility/artifact_manifest.csv)
- Environment archival records under `reproducibility/`

## Authors and license

Authors: Soumyadeep Ray and Ganesh Bagler. Correspondence:
bagler@iiitd.ac.in. This package is distributed under the MIT license included
in `LICENSE`.
