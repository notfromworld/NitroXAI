# Notebook/package parity report

This report compares `nitroxai==0.1.1` with the authoritative final notebook,
its frozen downstream artifacts, and the raw caches that notebook generated.
All checks were run with the `Python (NitroXAI CV)` kernel environment.

## Sources compared

- Notebook: `NitroXAI_ESM61_FINAL_COMPLETE.ipynb`
- Final checkpoints/scalers:
  `nitroxai_esm61_protocol_compare/full/{checkpoints,scalers}`
- Final independent-test artifacts:
  `nitroxai_esm61_full_nearopt_final/`
- Raw final test inputs:
  `nitroxai_esm61_final_full_test/`
- Interpretability artifacts:
  `nitroxai_esm61_full_nearopt_final/interpretability/`

## Structural parity

| Item | Notebook | Package | Result |
| --- | --- | --- | --- |
| Sequence cleaning | uppercase/remove whitespace; unknown -> X | `sequence.clean_sequence` | matched |
| Handcrafted raw input | 61 x 27 | `handcrafted.encode_handcrafted_window` | exact reference-cache match |
| ESM model | fair-esm `esm2_t30_150M_UR50D` | same pinned loader | matched |
| ESM representation | layer 30, 640 dimensions, `[0, 1:n+1]` | `ESMBackbone.embed_full` | matched |
| ESM context | full protein before site extraction | one shared protein embedding | matched |
| ESM terminal behavior | zero raw 640-vectors | `extract_esm_window` | matched |
| Preprocessing | saved fold scalers + sqrt(dim) | `transform_fold_inputs` | matched; never fits |
| Downstream state keys | Cell-2 `attention_esm` | identical module names/state load | strict load passes all 5 |
| Probability ensemble | mean of five sigmoid probabilities | same | matched |
| Threshold | `0.5757167935371399` | same frozen constant | matched |
| IG | manual 32-step logit IG | same manual calculation | matched |

## Live ESM checks

The live canonical fair-esm loader was used to encode complete reference
proteins on CUDA. The package's extracted ESM windows matched final saved raw
test-cache windows exactly (`max_abs_difference = 0.0`) for:

- P18669 C153: internal high-confidence SNO site
- O14508 C5: N-terminal site
- A0A024RBG1 C25: near-terminal/intermediate site

This proves the package does not independently encode a 61-residue window.

## GPU prediction checks

Live end-to-end package calls on the same four representative sites (the three
above plus P41091 C101, near the decision threshold) produced:

| Comparison | Maximum absolute difference | Classifications |
| --- | ---: | --- |
| individual fold probability | `2.9640961e-08` | identical |
| five-fold ensemble probability | `2.9785156e-08` | identical |

For small CUDA public queries, the package retains the notebook's 128-site
downstream kernel shape by internally repeating only the final site and
discarding repeated outputs. This does not alter the model's mathematical
inputs or aggregation, and avoids otherwise observed cuDNN LSTM last-bit
batch-size drift.

## Full independent-test replay

The package re-ran all five packaged downstream folds over the final saved
test raw handcrafted and full-ESM inputs (`10,138` sites) on CUDA. No ESM
embeddings were regenerated in this replay; the raw cache was used only to
validate downstream/checkpoint/scaler parity.

| Measure | Package replay |
| --- | ---: |
| Maximum fold probability difference | `0.0` |
| Maximum ensemble probability difference | `0.0` |
| Classifications identical | yes |
| ACC | `0.8084434799763267` |
| Sensitivity | `0.7891949152542372` |
| Specificity | `0.8128484848484848` |
| MCC | `0.5117955488462775` |
| Precision | `0.4911008569545155` |
| F1 | `0.6054449410808614` |
| AUROC | `0.8820050077041603` |
| AUPRC | `0.6254979176335943` |
| TP / TN / FP / FN | `1490 / 6706 / 1544 / 398` |

Machine-readable replay values are retained in
`reproducibility/independent_test_package_replay.json`.

## Integrated Gradients parity

For deterministic selected test site A8K7I4 C386, the package's raw
five-fold-mean IG matched the saved final arrays:

| Comparison | Maximum absolute difference |
| --- | ---: |
| signed position IG (61 positions) | `5.9604645e-08` |
| absolute position IG (61 positions) | `5.9604645e-08` |
| handcrafted/ESM modality absolute IG | `0.0` |

The package uses the notebook's zero standardized-space baseline, 32
right-Riemann points, logit target, cuDNN-off gradient context, and raw (not
display-normalized) aggregation.

## CPU note

CPU inference operates correctly but cuDNN/LSTM-free CPU kernels can differ
from the saved CUDA reference by up to approximately `1.4e-05` in fold
probability on tested sites. This is backend floating-point variation, not a
different ESM, scaler, checkpoint, threshold, or class; CPU/CUDA
classifications remained equivalent within the documented tolerance.

## Clean-wheel installation check

The built wheel was installed with `pip install --no-deps` into a fresh
temporary Python 3.11 virtual environment created from the authoritative
interpreter with its validated site packages available.  All commands were
executed from `/tmp`, so the package imported from the installed wheel rather
than the source tree:

```text
/tmp/nitroxai-wheel-*/venv/lib/python3.11/site-packages/nitroxai/__init__.py
```

`pip check` reported no broken requirements.  The installed console script
successfully ran `--version`, `--help`, `info`, raw-sequence prediction, FASTA
prediction, FASTA batch prediction, a live UniProt P04637 C182 prediction, and
a 32-step Integrated Gradients explanation.

For source-versus-installed-wheel P18669 C153 on CUDA, the maximum absolute
difference was `0.0` for every requested fold probability and for the ensemble
probability; the classifications were identical.  This also confirms that the
clean installation resolves the packaged checkpoints, scalers, and canonical
fair-esm cached weights without a development-machine runtime path.
