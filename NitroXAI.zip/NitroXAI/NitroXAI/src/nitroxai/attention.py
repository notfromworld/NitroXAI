"""The final notebook's one-layer ESM attention pooling equation."""

from __future__ import annotations

import torch
from torch import nn


def esm_attention_pool(esm_x: torch.Tensor, attention: nn.Linear) -> tuple[torch.Tensor, torch.Tensor]:
    """Return ``sum_i softmax(w^T tanh(e_i)+b) e_i`` and its weights."""

    scores = attention(torch.tanh(esm_x)).squeeze(-1)
    weights = torch.softmax(scores, dim=1)
    context = torch.sum(esm_x * weights.unsqueeze(-1), dim=1)
    return context, weights
