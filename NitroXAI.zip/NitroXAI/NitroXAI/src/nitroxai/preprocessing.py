"""Frozen fold-specific scaling used by final NitroXAI inference."""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

import numpy as np

from .constants import ESM_EMBED_DIM, HANDCRAFTED_CHANNELS, HAND_DIMS, HAND_HEADS, HAND_SLICES
from .exceptions import ArtifactError


def validate_scaler_bundle(scalers: Mapping[str, Any], *, fold: int | None = None) -> None:
    """Validate the seven handcrafted and one ESM fitted StandardScalers."""

    if scalers.get("protocol") != "full":
        raise ArtifactError("Scaler bundle is not the frozen FULL-protein protocol.")
    if fold is not None and int(scalers.get("fold_id", -1)) != fold:
        raise ArtifactError(f"Scaler bundle fold mismatch: expected {fold}.")
    if int(scalers.get("window_length", -1)) != 61:
        raise ArtifactError("Scaler bundle does not use Window-61.")
    if int(scalers.get("half_window", -1)) != 30:
        raise ArtifactError("Scaler bundle does not use half-window 30.")
    if int(scalers.get("esm_dim", -1)) != ESM_EMBED_DIM:
        raise ArtifactError("Scaler bundle has an unexpected ESM dimension.")
    hand_scalers = scalers.get("hand_scalers")
    if not isinstance(hand_scalers, Mapping) or set(hand_scalers) != set(HAND_HEADS):
        raise ArtifactError("Scaler bundle does not contain the seven frozen handcrafted heads.")
    for head in HAND_HEADS:
        scaler = hand_scalers[head]
        expected = HAND_DIMS[head]
        if not all(hasattr(scaler, attr) for attr in ("mean_", "scale_", "n_features_in_")):
            raise ArtifactError(f"Scaler for head {head!r} is not a fitted StandardScaler.")
        if int(scaler.n_features_in_) != expected or np.asarray(scaler.mean_).shape != (expected,):
            raise ArtifactError(f"Scaler for head {head!r} has an unexpected feature dimension.")
    esm_scaler = scalers.get("esm_scaler")
    if not all(hasattr(esm_scaler, attr) for attr in ("mean_", "scale_", "n_features_in_")):
        raise ArtifactError("ESM scaler is not a fitted StandardScaler.")
    if int(esm_scaler.n_features_in_) != ESM_EMBED_DIM or np.asarray(esm_scaler.mean_).shape != (
        ESM_EMBED_DIM,
    ):
        raise ArtifactError("ESM scaler has an unexpected feature dimension.")


def scaler_arrays(scalers: Mapping[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Build Cell-4's float32 scaling arrays from saved fitted scalers.

    The notebook intentionally applies a saved StandardScaler's statistics
    followed by division by ``sqrt(head_dimension)``.  It does not call
    ``fit`` or ``transform`` during inference.
    """

    validate_scaler_bundle(scalers)
    hand_mean = np.zeros(HANDCRAFTED_CHANNELS, dtype=np.float32)
    hand_denom = np.ones(HANDCRAFTED_CHANNELS, dtype=np.float32)
    for head in HAND_HEADS:
        channel_slice = HAND_SLICES[head]
        scaler = scalers["hand_scalers"][head]
        hand_mean[channel_slice] = np.asarray(scaler.mean_, dtype=np.float32)
        hand_denom[channel_slice] = np.asarray(scaler.scale_, dtype=np.float32) * np.float32(
            math.sqrt(HAND_DIMS[head])
        )
    esm_scaler = scalers["esm_scaler"]
    esm_mean = np.asarray(esm_scaler.mean_, dtype=np.float32)
    esm_denom = np.asarray(esm_scaler.scale_, dtype=np.float32) * np.float32(math.sqrt(ESM_EMBED_DIM))
    if hand_mean.shape != (HANDCRAFTED_CHANNELS,) or hand_denom.shape != (HANDCRAFTED_CHANNELS,):
        raise ArtifactError("Handcrafted scaling-array shape mismatch.")
    if esm_mean.shape != (ESM_EMBED_DIM,) or esm_denom.shape != (ESM_EMBED_DIM,):
        raise ArtifactError("ESM scaling-array shape mismatch.")
    if not all(np.isfinite(array).all() for array in (hand_mean, hand_denom, esm_mean, esm_denom)):
        raise ArtifactError("Saved scaling arrays contain NaN or Inf.")
    if np.any(hand_denom == 0) or np.any(esm_denom == 0):
        raise ArtifactError("Saved scaling arrays contain a zero denominator.")
    return hand_mean, hand_denom, esm_mean, esm_denom


def transform_fold_inputs(
    handcrafted_raw: np.ndarray,
    esm_raw: np.ndarray,
    scalers: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray]:
    """Apply one fold's frozen scaling without fitting any inference data."""

    hand = np.asarray(handcrafted_raw, dtype=np.float32)
    esm = np.asarray(esm_raw, dtype=np.float32)
    if hand.ndim != 3 or hand.shape[1:] != (61, HANDCRAFTED_CHANNELS):
        raise ValueError("Handcrafted input must have shape [sites, 61, 27].")
    if esm.ndim != 3 or esm.shape[1:] != (61, ESM_EMBED_DIM):
        raise ValueError("ESM input must have shape [sites, 61, 640].")
    if hand.shape[0] != esm.shape[0]:
        raise ValueError("Handcrafted and ESM site counts differ.")
    hand_mean, hand_denom, esm_mean, esm_denom = scaler_arrays(scalers)
    transformed_hand = (hand - hand_mean) / hand_denom
    transformed_esm = (esm - esm_mean) / esm_denom
    if not np.isfinite(transformed_hand).all() or not np.isfinite(transformed_esm).all():
        raise RuntimeError("Non-finite values after frozen scaler application.")
    return transformed_hand.astype(np.float32, copy=False), transformed_esm.astype(np.float32, copy=False)
