"""Internal utilities that do not change scientific inference behavior."""

from __future__ import annotations

from contextlib import contextmanager
from hashlib import sha256
from importlib import resources
from pathlib import Path
from typing import Iterator

import torch

from .exceptions import ArtifactError, NitroXAIError


@contextmanager
def package_data_path(relative_path: str) -> Iterator[Path]:
    """Yield a real path for a bundled asset without consulting ``cwd``."""

    resource = resources.files("nitroxai.data").joinpath(relative_path)
    if not resource.is_file():
        raise ArtifactError(f"Required packaged model asset is missing: {relative_path}")
    with resources.as_file(resource) as path:
        yield Path(path)


def package_data_text(relative_path: str) -> str:
    """Read a UTF-8 package resource."""

    resource = resources.files("nitroxai.data").joinpath(relative_path)
    if not resource.is_file():
        raise ArtifactError(f"Required packaged model asset is missing: {relative_path}")
    return resource.read_text(encoding="utf-8")


def sha256_file(path: Path) -> str:
    """Return a SHA-256 digest without reading an entire asset at once."""

    digest = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_device(requested: str | torch.device = "auto") -> torch.device:
    """Resolve documented ``auto``, ``cpu``, and ``cuda`` device choices."""

    if isinstance(requested, torch.device):
        device = requested
    else:
        value = str(requested).strip().lower()
        if value == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if value == "cpu":
            return torch.device("cpu")
        if value == "cuda":
            device = torch.device("cuda")
        elif value.startswith("cuda:"):
            device = torch.device(value)
        else:
            raise NitroXAIError("Device must be one of: auto, cpu, cuda.")

    if device.type == "cuda" and not torch.cuda.is_available():
        raise NitroXAIError("CUDA was requested, but no CUDA device is available.")
    if device.type not in {"cpu", "cuda"}:
        raise NitroXAIError("Device must be one of: auto, cpu, cuda.")
    return device
