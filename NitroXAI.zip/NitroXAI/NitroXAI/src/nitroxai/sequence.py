"""Notebook-parity sequence cleaning, FASTA input, and site coordinates."""

from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
from typing import Iterable

from .constants import AA_TO_INDEX, HALF_WINDOW
from .exceptions import SequenceValidationError, SiteValidationError


@dataclass(frozen=True)
class FastaRecord:
    """One normalized FASTA record used by the public prediction API."""

    identifier: str
    description: str
    sequence: str


def _is_nan_scalar(value: object) -> bool:
    """Handle the notebook's ``pd.isna`` empty-sequence behavior without pandas."""

    return isinstance(value, float) and math.isnan(value)


def clean_sequence(sequence: object, *, allow_empty: bool = False) -> str:
    """Reproduce the final notebook's cleaning exactly.

    Whitespace is removed, letters are uppercased, and every noncanonical
    amino-acid symbol is represented as ``X`` while preserving sequence length.
    This includes non-alphabetic symbols, matching ``clean_seq`` in Cell 2.
    """

    if sequence is None or _is_nan_scalar(sequence):
        cleaned = ""
    else:
        compact = "".join(str(sequence).upper().split())
        cleaned = "".join(aa if aa in AA_TO_INDEX else "X" for aa in compact)
    if not cleaned and not allow_empty:
        raise SequenceValidationError("Protein sequence is empty.")
    return cleaned


normalize_sequence = clean_sequence


def validate_site(sequence: str, position: int) -> int:
    """Validate a biological 1-based cysteine coordinate and return 0-based."""

    if isinstance(position, bool) or not isinstance(position, int):
        raise SiteValidationError("Position must be a 1-based integer.")
    if position < 1 or position > len(sequence):
        raise SiteValidationError(
            f"Position {position} is outside this sequence (length {len(sequence)})."
        )
    position0 = position - 1
    residue = sequence[position0]
    if residue != "C":
        raise SiteValidationError(
            f"Position {position} contains {residue!r}, not cysteine (C)."
        )
    return position0


def cysteine_positions(sequence: str) -> list[int]:
    """Return every cysteine coordinate using 1-based public numbering."""

    return [index + 1 for index, residue in enumerate(sequence) if residue == "C"]


def get_window(sequence: str, position0: int, half_window: int = HALF_WINDOW) -> str:
    """Return the final notebook's X-padded cysteine-centered sequence window."""

    sequence = clean_sequence(sequence)
    position0 = int(position0)
    half_window = int(half_window)
    if not 0 <= position0 < len(sequence):
        raise IndexError(f"Position {position0} outside sequence length {len(sequence)}.")
    if sequence[position0] != "C":
        raise ValueError(f"Target residue at {position0 + 1} is {sequence[position0]!r}, expected C.")
    padded = "X" * half_window + sequence + "X" * half_window
    center = position0 + half_window
    window = padded[center - half_window : center + half_window + 1]
    expected = 2 * half_window + 1
    if len(window) != expected:
        raise RuntimeError(f"Window length {len(window)} != {expected}.")
    return window


def get_window_valid_mask(sequence: str, position0: int, half_window: int = HALF_WINDOW) -> list[bool]:
    """Return which window coordinates originate from the real full protein."""

    sequence = clean_sequence(sequence)
    return [0 <= int(position0) + rel < len(sequence) for rel in range(-half_window, half_window + 1)]


def _finalize_record(
    records: list[FastaRecord],
    identifier: str | None,
    description: str | None,
    sequence_parts: list[str],
    source: str,
) -> None:
    if identifier is None:
        return
    sequence = clean_sequence("".join(sequence_parts))
    records.append(FastaRecord(identifier, description or identifier, sequence))


def parse_fasta_text(text: str, source: str = "FASTA input") -> list[FastaRecord]:
    """Parse standard multiline FASTA with notebook-parity sequence cleaning."""

    if text is None:
        raise SequenceValidationError(f"{source} is empty.")
    records: list[FastaRecord] = []
    identifier: str | None = None
    description: str | None = None
    sequence_parts: list[str] = []
    for line_number, line in enumerate(str(text).splitlines(), start=1):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith(">"):
            _finalize_record(records, identifier, description, sequence_parts, source)
            description = stripped[1:].strip()
            if not description:
                raise SequenceValidationError(f"{source}: FASTA header at line {line_number} is empty.")
            identifier = description.split()[0]
            sequence_parts = []
        else:
            if identifier is None:
                raise SequenceValidationError(
                    f"{source}: sequence data occurs before a FASTA header at line {line_number}."
                )
            sequence_parts.append("".join(stripped.split()))
    _finalize_record(records, identifier, description, sequence_parts, source)
    if not records:
        raise SequenceValidationError(f"{source} contains no FASTA records.")
    return records


def read_fasta(path: str | Path) -> list[FastaRecord]:
    """Read a UTF-8 FASTA file without depending on the working directory."""

    fasta_path = Path(path).expanduser()
    if not fasta_path.is_file():
        raise SequenceValidationError("FASTA input path does not exist or is not a file.")
    try:
        text = fasta_path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise SequenceValidationError("FASTA input must be UTF-8 text.") from exc
    except OSError as exc:
        raise SequenceValidationError("Unable to read FASTA input file.") from exc
    return parse_fasta_text(text, source="FASTA input")


def records_from_sequences(
    sequences: Iterable[tuple[str, str] | FastaRecord],
) -> list[FastaRecord]:
    """Normalize a programmatic batch of ``(protein_id, sequence)`` entries."""

    records: list[FastaRecord] = []
    for item in sequences:
        if isinstance(item, FastaRecord):
            records.append(FastaRecord(item.identifier, item.description, clean_sequence(item.sequence)))
            continue
        try:
            identifier, sequence = item
        except (TypeError, ValueError) as exc:
            raise SequenceValidationError(
                "Batch sequences must contain (protein_id, sequence) pairs."
            ) from exc
        identifier = str(identifier).strip()
        if not identifier:
            raise SequenceValidationError("A batch protein ID is empty.")
        records.append(FastaRecord(identifier, identifier, clean_sequence(sequence)))
    return records
