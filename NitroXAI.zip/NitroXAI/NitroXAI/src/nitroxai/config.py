"""Read and validate bundled final-model metadata."""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

from .constants import (
    ESM_EMBED_DIM,
    ESM_LAYER,
    ESM_MODEL_NAME,
    FINAL_THRESHOLD,
    HANDCRAFTED_CHANNELS,
    MODEL_PARAMETER_COUNT,
    N_FOLDS,
    WINDOW_SIZE,
)
from .exceptions import ArtifactError
from .utils import package_data_text


@lru_cache(maxsize=1)
def load_model_config() -> dict[str, Any]:
    """Return the notebook-derived bundled configuration."""

    config = json.loads(package_data_text("config/model_config.json"))
    expected = {
        "window_length": WINDOW_SIZE,
        "threshold": FINAL_THRESHOLD,
        "folds": N_FOLDS,
        "downstream_trainable_parameters": MODEL_PARAMETER_COUNT,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ArtifactError(f"Packaged model configuration has an invalid {key!r} value.")
    esm = config.get("esm", {})
    if esm.get("model") != ESM_MODEL_NAME or esm.get("layer") != ESM_LAYER:
        raise ArtifactError("Packaged model configuration has an invalid ESM model or layer.")
    if esm.get("dimension") != ESM_EMBED_DIM:
        raise ArtifactError("Packaged model configuration has an invalid ESM dimension.")
    if config.get("handcrafted", {}).get("channels") != HANDCRAFTED_CHANNELS:
        raise ArtifactError("Packaged model configuration has an invalid handcrafted dimension.")
    return config


@lru_cache(maxsize=1)
def load_asset_manifest() -> dict[str, Any]:
    """Return SHA-256 metadata for bundled frozen model artifacts."""

    return json.loads(package_data_text("config/package_artifact_manifest.json"))
