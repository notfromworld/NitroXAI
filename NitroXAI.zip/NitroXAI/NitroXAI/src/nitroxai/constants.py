"""Constants frozen from ``NitroXAI_ESM61_FINAL_COMPLETE.ipynb``."""

from __future__ import annotations

import math

WINDOW_SIZE = 61
HALF_WINDOW = 30
HANDCRAFTED_CHANNELS = 27
ESM_EMBED_DIM = 640
TOTAL_CHANNELS = HANDCRAFTED_CHANNELS + ESM_EMBED_DIM
N_FOLDS = 5
DROPOUT = 0.25
DEFAULT_BATCH_SIZE = 128
IG_STEPS = 32

FINAL_THRESHOLD = 0.5757167935371399
MODEL_ARCHITECTURE = "attention_esm"
MODEL_PARAMETER_COUNT = 195_970
HANDCRAFTED_PARAMETER_COUNT = 146_048
ESM_ATTENTION_PARAMETER_COUNT = 641
FUSION_CLASSIFIER_PARAMETER_COUNT = 49_281

ESM_MODEL_NAME = "esm2_t30_150M_UR50D"
ESM_LAYER = 30
ESM_IMPORT_NAME = "esm"
ESM_PACKAGE_NAME = "fair-esm"
ESM_PACKAGE_VERSION = "2.0.0"

# These values document observed notebook protocols.  They are not runtime
# truncation limits: the final human model attempted full protein encoding and
# delegated practical limits to fair-esm/PyTorch and available memory.
HUMAN_MAX_SEQUENCE_LENGTH_VALIDATED = 4_857
EXTERNAL_COMMON_PROTOCOL_LENGTH_CUTOFF = 5_000

AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
AA_TO_INDEX = {amino_acid: index for index, amino_acid in enumerate(AA_ORDER)}

HYDROPATHY = {
    "A": 1.8,
    "C": 2.5,
    "D": -3.5,
    "E": -3.5,
    "F": 2.8,
    "G": -0.4,
    "H": -3.2,
    "I": 4.5,
    "K": -3.9,
    "L": 3.8,
    "M": 1.9,
    "N": -3.5,
    "P": -1.6,
    "Q": -3.5,
    "R": -4.5,
    "S": -0.8,
    "T": -0.7,
    "V": 4.2,
    "W": -0.9,
    "Y": -1.3,
    "X": 0.0,
}

ACIDIC_RESIDUES = frozenset({"D", "E"})
BASIC_RESIDUES = frozenset({"K", "R", "H"})
PROLINE_TAU = 1.0

HAND_HEADS = ("aa", "hydro", "acid", "base", "cys", "pro", "dist")
HAND_DIMS = {
    "aa": 20,
    "hydro": 1,
    "acid": 1,
    "base": 1,
    "cys": 1,
    "pro": 1,
    "dist": 2,
}

HAND_SLICES: dict[str, slice] = {}
_cursor = 0
for _head in HAND_HEADS:
    _next = _cursor + HAND_DIMS[_head]
    HAND_SLICES[_head] = slice(_cursor, _next)
    _cursor = _next
del _cursor, _next, _head

ESM_SLICE = slice(HANDCRAFTED_CHANNELS, TOTAL_CHANNELS)

assert WINDOW_SIZE == 2 * HALF_WINDOW + 1
assert sum(HAND_DIMS.values()) == HANDCRAFTED_CHANNELS
assert TOTAL_CHANNELS == 667


def head_scale_factor(head: str) -> float:
    """Return the notebook's saved-scaler normalizer for a handcrafted head."""

    return math.sqrt(HAND_DIMS[head])
