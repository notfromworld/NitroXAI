"""Exact frozen downstream NitroXAI architecture (without ESM backbone weights)."""

from __future__ import annotations

import torch
from torch import nn

from .attention import esm_attention_pool
from .constants import (
    DROPOUT,
    ESM_EMBED_DIM,
    ESM_SLICE,
    HANDCRAFTED_CHANNELS,
    MODEL_PARAMETER_COUNT,
    TOTAL_CHANNELS,
)


class SequenceEncoder(nn.Module):
    """CNN + BiLSTM encoder mapping a 61 x 27 handcrafted input to 128 values."""

    def __init__(self, in_channels: int = HANDCRAFTED_CHANNELS, dropout: float = DROPOUT) -> None:
        super().__init__()
        if in_channels <= 0:
            raise ValueError("in_channels must be positive.")
        self.cnn = nn.Sequential(
            nn.Conv1d(in_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(64, 128, kernel_size=5, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(
            input_size=128,
            hidden_size=64,
            batch_first=True,
            bidirectional=True,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 1)
        x = self.cnn(x)
        x = x.permute(0, 2, 1)
        x, _ = self.lstm(x)
        return x.max(dim=1).values


class ClassifierHead(nn.Module):
    """The final 768 -> 64 -> 1 raw-logit classifier."""

    def __init__(self, in_dim: int, dropout: float = DROPOUT) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


class AttentionESMModel(nn.Module):
    """Final NitroXAI downstream model returning uncalibrated raw logits.

    The public path accepts the two notebook modalities separately: handcrafted
    ``[batch, 61, 27]`` and standardized contextual ESM ``[batch, 61, 640]``.
    For direct notebook audit, passing a single legacy ``[batch, 61, 667]``
    tensor is also supported and follows the original Cell-2 slicing code.
    """

    def __init__(
        self,
        in_channels: int = TOTAL_CHANNELS,
        esm_slice: slice = ESM_SLICE,
        dropout: float = DROPOUT,
    ) -> None:
        super().__init__()
        self.esm_slice = esm_slice
        self.esm_dim = esm_slice.stop - esm_slice.start
        self.other_dim = in_channels - self.esm_dim
        if self.esm_dim != ESM_EMBED_DIM:
            raise ValueError(f"Expected ESM dimension {ESM_EMBED_DIM}, got {self.esm_dim}.")
        if self.other_dim != HANDCRAFTED_CHANNELS:
            raise ValueError(f"Expected {HANDCRAFTED_CHANNELS} non-ESM channels, got {self.other_dim}.")
        # Names intentionally match the notebook state_dict exactly.
        self.esm_attn = nn.Linear(self.esm_dim, 1)
        self.hand_encoder = SequenceEncoder(self.other_dim, dropout=dropout)
        self.head = ClassifierHead(128 + self.esm_dim, dropout=dropout)

    def _components(
        self, handcrafted: torch.Tensor, esm: torch.Tensor | None
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if esm is None:
            if handcrafted.ndim != 3 or handcrafted.shape[-1] != TOTAL_CHANNELS:
                raise ValueError(
                    f"Legacy combined input must have shape [batch, length, {TOTAL_CHANNELS}]."
                )
            esm_x = handcrafted[:, :, self.esm_slice]
            other_x = torch.cat(
                [
                    handcrafted[:, :, : self.esm_slice.start],
                    handcrafted[:, :, self.esm_slice.stop :],
                ],
                dim=-1,
            )
            return other_x, esm_x
        if handcrafted.ndim != 3 or handcrafted.shape[-1] != HANDCRAFTED_CHANNELS:
            raise ValueError(
                f"Handcrafted input must have shape [batch, length, {HANDCRAFTED_CHANNELS}]."
            )
        if esm.ndim != 3 or esm.shape[-1] != ESM_EMBED_DIM:
            raise ValueError(f"ESM input must have shape [batch, length, {ESM_EMBED_DIM}].")
        if handcrafted.shape[:2] != esm.shape[:2]:
            raise ValueError("Handcrafted and ESM inputs must have matching batch and length dimensions.")
        return handcrafted, esm

    def forward(self, handcrafted: torch.Tensor, esm: torch.Tensor | None = None) -> torch.Tensor:
        """Return a raw logit for each input site."""

        other_x, esm_x = self._components(handcrafted, esm)
        esm_vec, _ = esm_attention_pool(esm_x, self.esm_attn)
        hand_vec = self.hand_encoder(other_x)
        return self.head(torch.cat([hand_vec, esm_vec], dim=-1))

    def forward_with_attention(
        self, handcrafted: torch.Tensor, esm: torch.Tensor | None = None
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Return raw logits and the learned 61-position ESM attention weights."""

        other_x, esm_x = self._components(handcrafted, esm)
        esm_vec, weights = esm_attention_pool(esm_x, self.esm_attn)
        hand_vec = self.hand_encoder(other_x)
        return self.head(torch.cat([hand_vec, esm_vec], dim=-1)), weights


NitroXAIModel = AttentionESMModel


def build_model(dropout: float = DROPOUT) -> AttentionESMModel:
    """Create the architecture used to load every frozen downstream fold."""

    return AttentionESMModel(in_channels=TOTAL_CHANNELS, esm_slice=ESM_SLICE, dropout=dropout)


def trainable_parameter_count(model: nn.Module) -> int:
    """Count downstream trainable parameters, excluding frozen ESM weights."""

    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)


def assert_expected_parameter_count(model: nn.Module) -> None:
    """Guard against silent architectural drift from the final notebook."""

    count = trainable_parameter_count(model)
    if count != MODEL_PARAMETER_COUNT:
        raise RuntimeError(
            f"Unexpected NitroXAI downstream parameter count: {count} != {MODEL_PARAMETER_COUNT}."
        )
