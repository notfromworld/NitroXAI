"""Public exception hierarchy for NitroXAI."""


class NitroXAIError(Exception):
    """Base class for anticipated user-facing NitroXAI errors."""


class ArtifactError(NitroXAIError):
    """A frozen package asset is absent, incompatible, or corrupted."""


class SequenceValidationError(NitroXAIError):
    """A supplied protein sequence cannot be used for inference."""


class SiteValidationError(SequenceValidationError):
    """A requested residue coordinate is invalid or does not identify cysteine."""


class ESMError(NitroXAIError):
    """The validated ESM-2 backbone could not be loaded or run."""


class UniProtError(NitroXAIError):
    """A UniProt accession could not be retrieved as a valid FASTA record."""
