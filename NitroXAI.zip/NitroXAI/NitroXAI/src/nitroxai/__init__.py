"""NitroXAI: full-protein ESM-2 S-nitrosylation site prediction."""

from .predictor import NitroXAIPredictor, PredictionResult

__version__ = "0.1.1"

__all__ = ["NitroXAIPredictor", "PredictionResult", "__version__"]
