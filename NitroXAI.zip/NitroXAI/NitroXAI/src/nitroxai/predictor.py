"""High-level, full-protein-context NitroXAI inference API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import torch

from .constants import DEFAULT_BATCH_SIZE, FINAL_THRESHOLD, HALF_WINDOW, N_FOLDS
from .ensemble import FoldArtifact, load_ensemble
from .esm import ESMBackbone, extract_esm_window
from .handcrafted import encode_handcrafted_window, encode_handcrafted_windows
from .preprocessing import transform_fold_inputs
from .sequence import (
    FastaRecord,
    clean_sequence,
    cysteine_positions,
    get_window,
    read_fasta,
    records_from_sequences,
    validate_site,
)
from .uniprot import fetch_uniprot_sequence, normalize_accession
from .utils import resolve_device


@dataclass(frozen=True)
class PredictionResult:
    """One residue-level five-fold NitroXAI prediction."""

    protein_id: str
    position: int
    residue: str
    probability: float
    prediction: int
    threshold: float
    sequence_length: int
    window_sequence: str
    fold_probabilities: tuple[float, ...] | None = None

    @property
    def prediction_label(self) -> str:
        return "SNO" if self.prediction else "Non-SNO"

    def to_dict(
        self,
        *,
        include_fold_probabilities: bool = False,
        include_context: bool = False,
    ) -> dict[str, object]:
        row: dict[str, object] = {
            "protein_id": self.protein_id,
            "position": self.position,
            "residue": self.residue,
            "probability": self.probability,
            "prediction": self.prediction_label,
            "prediction_binary": self.prediction,
            "threshold": self.threshold,
        }
        if include_context:
            row["sequence_length"] = self.sequence_length
            row["window_sequence"] = self.window_sequence
        if include_fold_probabilities and self.fold_probabilities is not None:
            for fold, probability in enumerate(self.fold_probabilities, start=1):
                row[f"fold_{fold}_probability"] = probability
        return row


class NitroXAIPredictor:
    """Frozen five-fold NitroXAI with one shared ESM-2 backbone.

    Public methods accept a complete protein sequence, not an already-extracted
    61-residue fragment.  For every protein, ESM-2 is run once over the full
    cleaned sequence; multiple cysteine windows reuse that contextual result.
    """

    def __init__(
        self,
        device: str | torch.device = "auto",
        *,
        batch_size: int = DEFAULT_BATCH_SIZE,
        verify_artifacts: bool = True,
        uniprot_timeout: float = 20.0,
        esm_backbone: ESMBackbone | None = None,
    ) -> None:
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size < 1:
            raise ValueError("batch_size must be a positive integer.")
        if uniprot_timeout <= 0:
            raise ValueError("uniprot_timeout must be positive.")
        # Cell 2 of the final notebook set these options before downstream
        # training/inference.  They do not alter learned weights; they retain
        # the validated deterministic cuDNN policy where supported.
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        self.device = resolve_device(device)
        self.batch_size = batch_size
        self.uniprot_timeout = float(uniprot_timeout)
        self._folds: list[FoldArtifact] = load_ensemble(
            self.device, verify_checksums=verify_artifacts
        )
        self._esm = esm_backbone if esm_backbone is not None else ESMBackbone(self.device)
        self._uniprot_cache: dict[str, FastaRecord] = {}

    @property
    def folds(self) -> tuple[FoldArtifact, ...]:
        """Expose loaded fold metadata without reloading model resources."""

        return tuple(self._folds)

    @property
    def esm_backbone(self) -> ESMBackbone:
        """Expose the single shared ESM backbone for inspection and auditing."""

        return self._esm

    def full_protein_embedding(self, sequence: str) -> np.ndarray:
        """Return the frozen final-layer ESM representation for a full sequence."""

        return self._esm.embed_full(clean_sequence(sequence))

    def raw_site_features(self, sequence: str, position: int) -> tuple[str, np.ndarray, np.ndarray]:
        """Return notebook-parity raw window, handcrafted, and contextual ESM inputs."""

        cleaned = clean_sequence(sequence)
        position0 = validate_site(cleaned, position)
        embedding = self._esm.embed_full(cleaned)
        return (
            get_window(cleaned, position0),
            encode_handcrafted_window(cleaned, position0),
            extract_esm_window(embedding, len(cleaned), position0),
        )

    def predict_site(
        self,
        sequence: str,
        position: int,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> PredictionResult:
        """Predict one requested 1-based cysteine from its full protein sequence."""

        cleaned = clean_sequence(sequence)
        position0 = validate_site(cleaned, position)
        return self._predict_positions(
            cleaned,
            [position0],
            protein_id=str(protein_id),
            include_fold_probabilities=include_fold_probabilities,
        )[0]

    def predict_all_cysteines(
        self,
        sequence: str,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Scan every cysteine while encoding the full protein once."""

        cleaned = clean_sequence(sequence)
        positions0 = [position - 1 for position in cysteine_positions(cleaned)]
        return self._predict_positions(
            cleaned,
            positions0,
            protein_id=str(protein_id),
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_sequence(
        self,
        sequence: str,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Alias for all-cysteine full-protein prediction."""

        return self.predict_all_cysteines(
            sequence,
            protein_id=protein_id,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_fasta(
        self, fasta_path: str, *, include_fold_probabilities: bool = False
    ) -> list[PredictionResult]:
        """Predict every cysteine from all records in a local FASTA file."""

        return self._predict_records(read_fasta(fasta_path), include_fold_probabilities=include_fold_probabilities)

    def predict_uniprot(
        self, accession: str, *, include_fold_probabilities: bool = False
    ) -> list[PredictionResult]:
        """Retrieve one full UniProt sequence then scan all its cysteines."""

        record = self._get_uniprot_record(accession)
        return self.predict_sequence(
            record.sequence,
            protein_id=record.identifier,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_uniprot_site(
        self, accession: str, position: int, *, include_fold_probabilities: bool = False
    ) -> PredictionResult:
        """Retrieve a full UniProt sequence then predict one requested cysteine."""

        record = self._get_uniprot_record(accession)
        return self.predict_site(
            record.sequence,
            position,
            protein_id=record.identifier,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_batch(
        self,
        sequences: Iterable[tuple[str, str] | FastaRecord],
        *,
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Predict an iterable of full protein records, one ESM embedding each."""

        return self._predict_records(
            records_from_sequences(sequences), include_fold_probabilities=include_fold_probabilities
        )

    def explain_site(
        self,
        sequence: str,
        position: int,
        *,
        protein_id: str = "sequence",
        include_attention: bool = False,
    ):
        """Return 61 raw logit-IG attributions without recomputing full ESM."""

        from .interpretability import explain_raw_site

        cleaned = clean_sequence(sequence)
        position0 = validate_site(cleaned, position)
        embedding = self._esm.embed_full(cleaned)
        handcrafted_raw = encode_handcrafted_window(cleaned, position0)
        esm_raw = extract_esm_window(embedding, len(cleaned), position0)
        prediction = self._predict_raw_modalities(
            cleaned,
            [position0],
            np.expand_dims(handcrafted_raw, axis=0),
            np.expand_dims(esm_raw, axis=0),
            protein_id=str(protein_id),
            include_fold_probabilities=False,
        )[0]
        return explain_raw_site(
            folds=self._folds,
            device=self.device,
            sequence=cleaned,
            position0=position0,
            protein_id=str(protein_id),
            handcrafted_raw=handcrafted_raw,
            esm_raw=esm_raw,
            probability=prediction.probability,
            prediction=prediction.prediction,
            threshold=prediction.threshold,
            include_attention=include_attention,
        )

    def explain_uniprot_site(self, accession: str, position: int, *, include_attention: bool = False):
        """Retrieve a full UniProt sequence then explain one cysteine prediction."""

        record = self._get_uniprot_record(accession)
        return self.explain_site(
            record.sequence,
            position,
            protein_id=record.identifier,
            include_attention=include_attention,
        )

    def _get_uniprot_record(self, accession: str) -> FastaRecord:
        normalized = normalize_accession(accession)
        if normalized not in self._uniprot_cache:
            self._uniprot_cache[normalized] = fetch_uniprot_sequence(
                normalized, timeout=self.uniprot_timeout
            )
        return self._uniprot_cache[normalized]

    def _predict_records(
        self,
        records: Iterable[FastaRecord],
        *,
        include_fold_probabilities: bool,
    ) -> list[PredictionResult]:
        results: list[PredictionResult] = []
        for record in records:
            # Per-record call intentionally gives each full protein one ESM run;
            # it never batches or encodes isolated cysteine windows with ESM.
            results.extend(
                self.predict_sequence(
                    record.sequence,
                    protein_id=record.identifier,
                    include_fold_probabilities=include_fold_probabilities,
                )
            )
        return results

    def _predict_positions(
        self,
        sequence: str,
        positions0: list[int],
        *,
        protein_id: str,
        include_fold_probabilities: bool,
    ) -> list[PredictionResult]:
        if not positions0:
            return []
        for position0 in positions0:
            if not 0 <= position0 < len(sequence) or sequence[position0] != "C":
                raise ValueError("All internal prediction positions must identify cysteine residues.")
        full_embedding = self._esm.embed_full(sequence)
        handcrafted_raw = encode_handcrafted_windows(sequence, positions0)
        esm_raw = np.stack(
            [extract_esm_window(full_embedding, len(sequence), position0) for position0 in positions0], axis=0
        ).astype(np.float32, copy=False)
        return self._predict_raw_modalities(
            sequence,
            positions0,
            handcrafted_raw,
            esm_raw,
            protein_id=protein_id,
            include_fold_probabilities=include_fold_probabilities,
        )

    def _predict_raw_modalities(
        self,
        sequence: str,
        positions0: list[int],
        handcrafted_raw: np.ndarray,
        esm_raw: np.ndarray,
        *,
        protein_id: str,
        include_fold_probabilities: bool,
    ) -> list[PredictionResult]:
        matrix = self._fold_probability_matrix(handcrafted_raw, esm_raw)
        ensemble_probability = matrix.mean(axis=0).astype(np.float32)
        return [
            self._make_result(
                protein_id=protein_id,
                sequence=sequence,
                position0=position0,
                probability=float(ensemble_probability[index]),
                fold_probabilities=(
                    tuple(float(matrix[fold, index]) for fold in range(N_FOLDS))
                    if include_fold_probabilities
                    else None
                ),
            )
            for index, position0 in enumerate(positions0)
        ]

    def _fold_probability_matrix(
        self, handcrafted_raw: np.ndarray, esm_raw: np.ndarray
    ) -> np.ndarray:
        probabilities: list[np.ndarray] = []
        for artifact in self._folds:
            hand, esm = transform_fold_inputs(handcrafted_raw, esm_raw, artifact.scalers)
            probabilities.append(self._run_model(artifact.model, hand, esm))
        matrix = np.stack(probabilities, axis=0).astype(np.float32, copy=False)
        expected = (N_FOLDS, len(handcrafted_raw))
        if matrix.shape != expected:
            raise RuntimeError(f"Unexpected fold probability matrix shape: {matrix.shape} != {expected}.")
        return matrix

    def _run_model(
        self, model: torch.nn.Module, handcrafted: np.ndarray, esm: np.ndarray
    ) -> np.ndarray:
        probabilities: list[np.ndarray] = []
        model.eval()
        with torch.inference_mode():
            for start in range(0, len(handcrafted), self.batch_size):
                hand_values = handcrafted[start : start + self.batch_size]
                esm_values = esm[start : start + self.batch_size]
                # The final independent-test notebook used a 128-site CUDA
                # DataLoader.  cuDNN LSTM kernels can otherwise produce a few
                # last-bit differences for a one-site public query solely from
                # a changed batch dimension.  For a small standalone query,
                # repeat its final site only to retain the validated 128-site
                # kernel shape, then discard the repeated outputs.  No site
                # features, scaler values, logits, or ensemble operation are
                # changed; this is numerically inert under exact arithmetic.
                original_count = len(hand_values)
                if self.device.type == "cuda" and len(handcrafted) < self.batch_size:
                    repeats = self.batch_size - original_count
                    if repeats:
                        hand_values = np.concatenate(
                            [hand_values, np.repeat(hand_values[-1:], repeats, axis=0)], axis=0
                        )
                        esm_values = np.concatenate(
                            [esm_values, np.repeat(esm_values[-1:], repeats, axis=0)], axis=0
                        )
                hand_batch = torch.from_numpy(hand_values).to(
                    self.device, dtype=torch.float32, non_blocking=self.device.type == "cuda"
                )
                esm_batch = torch.from_numpy(esm_values).to(
                    self.device, dtype=torch.float32, non_blocking=self.device.type == "cuda"
                )
                logits = model(hand_batch, esm_batch).reshape(-1)
                probabilities.append(
                    torch.sigmoid(logits).detach().cpu().numpy().reshape(-1)[:original_count]
                )
        return np.concatenate(probabilities).astype(np.float32, copy=False)

    @staticmethod
    def _make_result(
        *,
        protein_id: str,
        sequence: str,
        position0: int,
        probability: float,
        fold_probabilities: tuple[float, ...] | None,
    ) -> PredictionResult:
        return PredictionResult(
            protein_id=protein_id,
            position=position0 + 1,
            residue=sequence[position0],
            probability=probability,
            prediction=int(probability >= FINAL_THRESHOLD),
            threshold=FINAL_THRESHOLD,
            sequence_length=len(sequence),
            window_sequence=get_window(sequence, position0, HALF_WINDOW),
            fold_probabilities=fold_probabilities,
        )
