"""The 61 x 27 handcrafted representation frozen in the final notebook."""

from __future__ import annotations

import numpy as np

from .constants import (
    AA_TO_INDEX,
    ACIDIC_RESIDUES,
    BASIC_RESIDUES,
    HANDCRAFTED_CHANNELS,
    HALF_WINDOW,
    HYDROPATHY,
    PROLINE_TAU,
)
from .sequence import clean_sequence, get_window


def encode_handcrafted_window(
    sequence: str,
    position0: int,
    half_window: int = HALF_WINDOW,
) -> np.ndarray:
    """Return raw float32 features with shape ``[61, 27]``.

    No standardization occurs here.  In particular, X terminal padding has
    zero biochemical channels while its two relative-position channels remain
    populated, exactly as in Cell 2 of the final notebook.
    """

    sequence = clean_sequence(sequence)
    window = get_window(sequence, position0, half_window)
    sigma = max(2.0, half_window / 3.0)
    rows: list[np.ndarray] = []
    for index, amino_acid in enumerate(window):
        relative_position = index - half_window
        aa_vector = np.zeros(20, dtype=np.float32)
        if amino_acid in AA_TO_INDEX:
            aa_vector[AA_TO_INDEX[amino_acid]] = 1.0
        hydro_vector = np.array([HYDROPATHY.get(amino_acid, 0.0)], dtype=np.float32)
        acidic_vector = np.array([float(amino_acid in ACIDIC_RESIDUES)], dtype=np.float32)
        basic_vector = np.array([float(amino_acid in BASIC_RESIDUES)], dtype=np.float32)
        cysteine_vector = np.array([float(amino_acid == "C")], dtype=np.float32)
        proline_vector = np.array(
            [np.exp(-abs(relative_position) / PROLINE_TAU) if amino_acid == "P" else 0.0],
            dtype=np.float32,
        )
        distance_vector = np.array(
            [
                relative_position / max(1, half_window),
                np.exp(-abs(relative_position) / sigma),
            ],
            dtype=np.float32,
        )
        rows.append(
            np.concatenate(
                [
                    aa_vector,
                    hydro_vector,
                    acidic_vector,
                    basic_vector,
                    cysteine_vector,
                    proline_vector,
                    distance_vector,
                ],
                axis=0,
            )
        )
    output = np.asarray(rows, dtype=np.float32)
    expected = (2 * half_window + 1, HANDCRAFTED_CHANNELS)
    if output.shape != expected:
        raise RuntimeError(f"Handcrafted window shape mismatch: {output.shape} != {expected}.")
    if not np.isfinite(output).all():
        raise RuntimeError("Handcrafted window contains NaN/Inf.")
    return output


def encode_handcrafted_windows(sequence: str, positions0: list[int]) -> np.ndarray:
    """Build raw handcrafted windows for multiple sites in a single protein."""

    if not positions0:
        return np.empty((0, 2 * HALF_WINDOW + 1, HANDCRAFTED_CHANNELS), dtype=np.float32)
    return np.stack(
        [encode_handcrafted_window(sequence, position0, HALF_WINDOW) for position0 in positions0],
        axis=0,
    ).astype(np.float32, copy=False)
