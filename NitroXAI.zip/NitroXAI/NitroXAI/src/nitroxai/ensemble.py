"""Loading and validation of the final five frozen NitroXAI downstream folds."""

from __future__ import annotations

from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import warnings

import joblib
import torch

from .config import load_asset_manifest
from .constants import (
    DROPOUT,
    ESM_EMBED_DIM,
    ESM_MODEL_NAME,
    ESM_SLICE,
    HALF_WINDOW,
    N_FOLDS,
    TOTAL_CHANNELS,
    WINDOW_SIZE,
)
from .exceptions import ArtifactError
from .model import AttentionESMModel, assert_expected_parameter_count
from .preprocessing import validate_scaler_bundle
from .utils import package_data_path, sha256_file


@dataclass
class FoldArtifact:
    """One matching downstream checkpoint and saved scaler bundle."""

    fold: int
    model: AttentionESMModel
    scalers: dict[str, Any]
    metadata: dict[str, Any]


def _torch_load(path: Path, device: torch.device) -> dict[str, Any]:
    try:
        checkpoint = torch.load(path, map_location=device, weights_only=False)
    except TypeError:  # pragma: no cover - compatibility with old torch
        checkpoint = torch.load(path, map_location=device)
    except Exception as exc:
        raise ArtifactError(f"Unable to load frozen checkpoint {path.name!r}.") from exc
    if not isinstance(checkpoint, dict):
        raise ArtifactError(f"Frozen checkpoint {path.name!r} has an unexpected format.")
    return checkpoint


def _load_scalers(path: Path) -> dict[str, Any]:
    try:
        from sklearn.exceptions import InconsistentVersionWarning

        with warnings.catch_warnings():
            warnings.simplefilter("error", InconsistentVersionWarning)
            scalers = joblib.load(path)
    except Warning as exc:
        raise ArtifactError(
            f"Scaler {path.name!r} raised a serialization-version warning; "
            "use the recorded NitroXAI CV environment."
        ) from exc
    except Exception as exc:
        raise ArtifactError(f"Unable to load frozen scaler bundle {path.name!r}.") from exc
    if not isinstance(scalers, dict):
        raise ArtifactError(f"Frozen scaler bundle {path.name!r} has an unexpected format.")
    return scalers


def verify_packaged_artifacts() -> None:
    """Verify every bundled downstream checkpoint/scaler against its SHA-256."""

    manifest = load_asset_manifest()
    for artifact in manifest.get("artifacts", []):
        relative_path = artifact["packaged_path"]
        with package_data_path(relative_path) as path:
            actual = sha256_file(path)
        if actual != artifact["sha256"]:
            raise ArtifactError(f"Packaged model asset checksum mismatch for {relative_path!r}.")


def _validate_checkpoint_metadata(checkpoint: dict[str, Any], fold: int) -> None:
    expected = {
        "protocol": "full",
        "fold_id": fold,
        "half_window": HALF_WINDOW,
        "window_length": WINDOW_SIZE,
        "in_channels": TOTAL_CHANNELS,
        "esm_slice_start": ESM_SLICE.start,
        "esm_slice_stop": ESM_SLICE.stop,
        "esm_model_name": ESM_MODEL_NAME,
    }
    for key, value in expected.items():
        if checkpoint.get(key) != value:
            raise ArtifactError(
                f"Checkpoint fold {fold} metadata mismatch for {key!r}: "
                f"expected {value!r}, found {checkpoint.get(key)!r}."
            )
    if "model_state_dict" not in checkpoint:
        raise ArtifactError(f"Checkpoint fold {fold} does not contain model_state_dict.")


def load_ensemble(device: torch.device, verify_checksums: bool = True) -> list[FoldArtifact]:
    """Load each downstream model exactly once; ESM remains shared elsewhere."""

    if verify_checksums:
        verify_packaged_artifacts()
    artifacts: list[FoldArtifact] = []
    with ExitStack() as stack:
        for fold in range(1, N_FOLDS + 1):
            checkpoint_path = stack.enter_context(
                package_data_path(f"checkpoints/fold_{fold}_window61.pt")
            )
            scaler_path = stack.enter_context(
                package_data_path(f"scalers/fold_{fold}_window61_scalers.joblib")
            )
            checkpoint = _torch_load(checkpoint_path, device)
            _validate_checkpoint_metadata(checkpoint, fold)
            scalers = _load_scalers(scaler_path)
            validate_scaler_bundle(scalers, fold=fold)
            if scalers.get("esm_model_name") != ESM_MODEL_NAME or int(scalers.get("esm_dim", -1)) != ESM_EMBED_DIM:
                raise ArtifactError(f"Scaler bundle for fold {fold} does not match the frozen ESM configuration.")
            model = AttentionESMModel(
                in_channels=TOTAL_CHANNELS,
                esm_slice=ESM_SLICE,
                dropout=DROPOUT,
            ).to(device)
            assert_expected_parameter_count(model)
            try:
                model.load_state_dict(checkpoint["model_state_dict"], strict=True)
            except RuntimeError as exc:
                raise ArtifactError(
                    f"Checkpoint fold {fold} has missing, unexpected, or incompatible state keys."
                ) from exc
            model.eval()
            artifacts.append(FoldArtifact(fold, model, scalers, checkpoint))
    if len(artifacts) != N_FOLDS:
        raise ArtifactError(f"Expected {N_FOLDS} frozen folds, loaded {len(artifacts)}.")
    return artifacts
