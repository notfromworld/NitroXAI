"""Stable table, CSV, JSON, and file-output helpers for the CLI."""

from __future__ import annotations

import csv
import io
import json
from collections.abc import Iterable, Mapping
from pathlib import Path


def _columns(rows: Iterable[Mapping[str, object]]) -> list[str]:
    columns: list[str] = []
    for row in rows:
        for column in row:
            if column not in columns:
                columns.append(column)
    return columns


def rows_to_json(rows: list[Mapping[str, object]]) -> str:
    return json.dumps(rows, indent=2, allow_nan=False) + "\n"


def rows_to_csv(rows: list[Mapping[str, object]]) -> str:
    if not rows:
        return ""
    columns = _columns(rows)
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def _format_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return repr(value)
    return str(value)


def rows_to_table(rows: list[Mapping[str, object]]) -> str:
    if not rows:
        return "No cysteine sites found.\n"
    columns = _columns(rows)
    rendered = [[_format_value(row.get(column)) for column in columns] for row in rows]
    widths = [max(len(column), *(len(row[index]) for row in rendered)) for index, column in enumerate(columns)]
    header = "  ".join(column.ljust(width) for column, width in zip(columns, widths))
    separator = "  ".join("-" * width for width in widths)
    body = ["  ".join(value.ljust(width) for value, width in zip(row, widths)) for row in rendered]
    return "\n".join([header, separator, *body]) + "\n"


def render_rows(rows: list[Mapping[str, object]], output_format: str) -> str:
    if output_format == "json":
        return rows_to_json(rows)
    if output_format == "csv":
        return rows_to_csv(rows)
    if output_format == "table":
        return rows_to_table(rows)
    raise ValueError(f"Unsupported output format: {output_format}")


def write_rows(path: str | Path, rows: list[Mapping[str, object]], output_format: str) -> None:
    """Write output without using assumptions about the current working directory."""

    output_path = Path(path).expanduser()
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(render_rows(rows, output_format), encoding="utf-8")
    except OSError as exc:
        raise OSError("Unable to write output file.") from exc
