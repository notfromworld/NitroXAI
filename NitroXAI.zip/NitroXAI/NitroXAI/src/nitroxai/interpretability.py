"""Notebook-parity manual Integrated Gradients for final NitroXAI."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import torch

from .constants import HALF_WINDOW, IG_STEPS, N_FOLDS
from .ensemble import FoldArtifact
from .preprocessing import transform_fold_inputs
from .sequence import get_window


@dataclass(frozen=True)
class ResidueAttribution:
    """Raw five-fold ensemble attributions for one of the 61 positions."""

    position: int | None
    relative_position: int
    residue: str
    signed_ig: float
    absolute_ig: float
    handcrafted_abs_ig: float
    esm_abs_ig: float
    handcrafted_fraction: float
    esm_fraction: float
    attention_weight: float | None = None

    def to_dict(self, *, include_attention: bool = False) -> dict[str, object]:
        row: dict[str, object] = {
            "position": self.position,
            "relative_position": self.relative_position,
            "residue": self.residue,
            "signed_ig": self.signed_ig,
            "absolute_ig": self.absolute_ig,
            "handcrafted_abs_ig": self.handcrafted_abs_ig,
            "esm_abs_ig": self.esm_abs_ig,
            "handcrafted_fraction": self.handcrafted_fraction,
            "esm_fraction": self.esm_fraction,
        }
        if include_attention and self.attention_weight is not None:
            row["esm_attention_weight"] = self.attention_weight
        return row


@dataclass(frozen=True)
class SiteExplanation:
    """Raw logit-IG explanation for a single cysteine-centered full-protein site."""

    protein_id: str
    target_position: int
    target_residue: str
    probability: float
    prediction: int
    threshold: float
    window_sequence: str
    ig_steps: int
    baseline: str
    target: str
    handcrafted_abs_ig: float
    esm_abs_ig: float
    handcrafted_fraction: float
    esm_fraction: float
    fold_completeness_absolute_errors: tuple[float, ...]
    rows: tuple[ResidueAttribution, ...]

    def to_rows(self, *, include_attention: bool = False) -> list[dict[str, object]]:
        """Render all residue-level output rows for table, CSV, or JSON output."""

        rows: list[dict[str, object]] = []
        for residue in self.rows:
            row = residue.to_dict(include_attention=include_attention)
            row.update(
                {
                    "protein_id": self.protein_id,
                    "target_position": self.target_position,
                    "target_residue": self.target_residue,
                    "probability": self.probability,
                    "prediction": "SNO" if self.prediction else "Non-SNO",
                    "prediction_binary": self.prediction,
                    "threshold": self.threshold,
                }
            )
            rows.append(row)
        return rows


@contextmanager
def _cudnn_off_for_ig(device: torch.device):
    """Use the final notebook's cuDNN-safe full-batch IG context."""

    if device.type == "cuda":
        with torch.backends.cudnn.flags(enabled=False):
            yield
    else:
        yield


def integrated_gradients(
    model: torch.nn.Module,
    handcrafted_scaled: np.ndarray,
    esm_scaled: np.ndarray,
    *,
    device: torch.device,
    steps: int = IG_STEPS,
) -> tuple[np.ndarray, np.ndarray, float, float, float]:
    """Implement the final Cell-7 right-Riemann, zero-baseline logit IG.

    This deliberately does not substitute Captum.  The authoritative notebook
    manually creates all 32 interpolation points at once, averages gradients,
    and attributes the pre-sigmoid model logit in fold-standardized space.
    """

    if steps != IG_STEPS:
        raise ValueError(f"Notebook-parity Integrated Gradients requires exactly {IG_STEPS} steps.")
    hand = torch.as_tensor(handcrafted_scaled, dtype=torch.float32, device=device)
    esm = torch.as_tensor(esm_scaled, dtype=torch.float32, device=device)
    baseline_hand = torch.zeros_like(hand)
    baseline_esm = torch.zeros_like(esm)
    alphas = torch.linspace(
        1.0 / float(steps), 1.0, steps, device=device, dtype=torch.float32
    ).view(steps, 1, 1)
    interpolated_hand = (
        baseline_hand.unsqueeze(0) + alphas * (hand - baseline_hand).unsqueeze(0)
    ).detach()
    interpolated_esm = (
        baseline_esm.unsqueeze(0) + alphas * (esm - baseline_esm).unsqueeze(0)
    ).detach()
    interpolated_hand.requires_grad_(True)
    interpolated_esm.requires_grad_(True)
    model.eval()
    with _cudnn_off_for_ig(device):
        logits = model(interpolated_hand, interpolated_esm)
        grad_hand, grad_esm = torch.autograd.grad(
            logits.sum(),
            (interpolated_hand, interpolated_esm),
            retain_graph=False,
            create_graph=False,
        )
    attr_hand = (hand - baseline_hand) * grad_hand.mean(dim=0)
    attr_esm = (esm - baseline_esm) * grad_esm.mean(dim=0)
    with torch.inference_mode():
        fx = float(model(hand.unsqueeze(0), esm.unsqueeze(0)).item())
        f0 = float(model(baseline_hand.unsqueeze(0), baseline_esm.unsqueeze(0)).item())
    attr_sum = float((attr_hand.sum() + attr_esm.sum()).item())
    completeness_abs_error = abs(attr_sum - (fx - f0))
    return (
        attr_hand.detach().cpu().numpy().astype(np.float32),
        attr_esm.detach().cpu().numpy().astype(np.float32),
        fx,
        f0,
        completeness_abs_error,
    )


def explain_raw_site(
    *,
    folds: Iterable[FoldArtifact],
    device: torch.device,
    sequence: str,
    position0: int,
    protein_id: str,
    handcrafted_raw: np.ndarray,
    esm_raw: np.ndarray,
    probability: float,
    prediction: int,
    threshold: float,
    include_attention: bool = False,
) -> SiteExplanation:
    """Explain already-built raw inputs without re-embedding the protein."""

    fold_list = list(folds)
    if len(fold_list) != N_FOLDS:
        raise RuntimeError(f"Expected {N_FOLDS} loaded folds for Integrated Gradients.")
    hand_raw = np.asarray(handcrafted_raw, dtype=np.float32)
    esm_raw = np.asarray(esm_raw, dtype=np.float32)
    if hand_raw.shape != (61, 27) or esm_raw.shape != (61, 640):
        raise ValueError("Raw explanation inputs must have shapes [61, 27] and [61, 640].")

    fold_hand_attrs: list[np.ndarray] = []
    fold_esm_attrs: list[np.ndarray] = []
    fold_attention: list[np.ndarray] = []
    completeness: list[float] = []
    for artifact in fold_list:
        hand_scaled, esm_scaled = transform_fold_inputs(
            hand_raw[None, ...], esm_raw[None, ...], artifact.scalers
        )
        attr_hand, attr_esm, _, _, error = integrated_gradients(
            artifact.model,
            hand_scaled[0],
            esm_scaled[0],
            device=device,
        )
        fold_hand_attrs.append(attr_hand)
        fold_esm_attrs.append(attr_esm)
        completeness.append(error)
        if include_attention:
            artifact.model.eval()
            with torch.inference_mode():
                hand_tensor = torch.as_tensor(hand_scaled, dtype=torch.float32, device=device)
                esm_tensor = torch.as_tensor(esm_scaled, dtype=torch.float32, device=device)
                _, weights = artifact.model.forward_with_attention(hand_tensor, esm_tensor)
            fold_attention.append(weights[0].detach().cpu().numpy().astype(np.float32))
        artifact.model.eval()

    hand_attrs = np.stack(fold_hand_attrs, axis=0)
    esm_attrs = np.stack(fold_esm_attrs, axis=0)
    fold_signed = hand_attrs.sum(axis=-1) + esm_attrs.sum(axis=-1)
    fold_absolute = np.abs(hand_attrs).sum(axis=-1) + np.abs(esm_attrs).sum(axis=-1)
    ensemble_signed = fold_signed.mean(axis=0)
    ensemble_absolute = fold_absolute.mean(axis=0)
    ensemble_hand_absolute = np.abs(hand_attrs).sum(axis=-1).mean(axis=0)
    ensemble_esm_absolute = np.abs(esm_attrs).sum(axis=-1).mean(axis=0)
    attention = np.stack(fold_attention, axis=0).mean(axis=0) if fold_attention else None

    handcrafted_abs = float(np.abs(hand_attrs).sum(axis=(1, 2)).mean())
    esm_abs = float(np.abs(esm_attrs).sum(axis=(1, 2)).mean())
    modality_total = handcrafted_abs + esm_abs
    handcrafted_fraction = handcrafted_abs / modality_total if modality_total > 0 else 0.0
    esm_fraction = esm_abs / modality_total if modality_total > 0 else 0.0
    window = get_window(sequence, position0, HALF_WINDOW)
    rows: list[ResidueAttribution] = []
    for index, residue in enumerate(window):
        relative_position = index - HALF_WINDOW
        sequence_index = position0 + relative_position
        protein_position = sequence_index + 1 if 0 <= sequence_index < len(sequence) else None
        local_total = float(ensemble_hand_absolute[index] + ensemble_esm_absolute[index])
        rows.append(
            ResidueAttribution(
                position=protein_position,
                relative_position=relative_position,
                residue=residue,
                signed_ig=float(ensemble_signed[index]),
                absolute_ig=float(ensemble_absolute[index]),
                handcrafted_abs_ig=float(ensemble_hand_absolute[index]),
                esm_abs_ig=float(ensemble_esm_absolute[index]),
                handcrafted_fraction=(float(ensemble_hand_absolute[index]) / local_total if local_total > 0 else 0.0),
                esm_fraction=(float(ensemble_esm_absolute[index]) / local_total if local_total > 0 else 0.0),
                attention_weight=(float(attention[index]) if attention is not None else None),
            )
        )
    return SiteExplanation(
        protein_id=protein_id,
        target_position=position0 + 1,
        target_residue=sequence[position0],
        probability=float(probability),
        prediction=int(prediction),
        threshold=float(threshold),
        window_sequence=window,
        ig_steps=IG_STEPS,
        baseline="zero in fold-standardized input space (fold-training feature mean)",
        target="model logit",
        handcrafted_abs_ig=handcrafted_abs,
        esm_abs_ig=esm_abs,
        handcrafted_fraction=handcrafted_fraction,
        esm_fraction=esm_fraction,
        fold_completeness_absolute_errors=tuple(float(value) for value in completeness),
        rows=tuple(rows),
    )
