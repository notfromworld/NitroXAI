"""Timeout-bounded UniProt FASTA retrieval for full-protein NitroXAI input."""

from __future__ import annotations

import re
from urllib.parse import quote

import requests

from .exceptions import UniProtError
from .sequence import FastaRecord, parse_fasta_text

UNIPROT_FASTA_URL = "https://rest.uniprot.org/uniprotkb/{accession}.fasta"
_ACCESSION_RE = re.compile(r"[A-Z0-9]{1,20}")


def normalize_accession(accession: str) -> str:
    """Validate one accession before it is inserted into the official endpoint."""

    value = str(accession).strip().upper()
    if not _ACCESSION_RE.fullmatch(value):
        raise UniProtError(f"Invalid UniProt accession: {accession!r}.")
    return value


def fetch_uniprot_sequence(
    accession: str,
    *,
    timeout: float = 20.0,
    session: requests.Session | None = None,
) -> FastaRecord:
    """Fetch exactly one full FASTA sequence from UniProt's REST endpoint."""

    normalized = normalize_accession(accession)
    url = UNIPROT_FASTA_URL.format(accession=quote(normalized, safe=""))
    client = session if session is not None else requests
    try:
        response = client.get(url, timeout=timeout)
    except requests.RequestException as exc:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        ) from exc
    if response.status_code != 200:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        )
    try:
        records = parse_fasta_text(response.text, source=f"UniProt accession {normalized}")
    except Exception as exc:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        ) from exc
    if len(records) != 1:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        )
    record = records[0]
    return FastaRecord(normalized, record.description, record.sequence)
