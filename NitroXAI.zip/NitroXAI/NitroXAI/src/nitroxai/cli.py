"""Command-line interface for frozen full-protein NitroXAI inference."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
from typing import Sequence

import torch

from . import __version__
from .constants import (
    ESM_EMBED_DIM,
    ESM_LAYER,
    ESM_MODEL_NAME,
    FINAL_THRESHOLD,
    HANDCRAFTED_CHANNELS,
    MODEL_PARAMETER_COUNT,
    N_FOLDS,
    WINDOW_SIZE,
)
from .esm import esm_environment
from .exceptions import NitroXAIError
from .io import render_rows, write_rows
from .model import build_model, trainable_parameter_count
from .predictor import NitroXAIPredictor, PredictionResult
from .sequence import read_fasta


def build_parser() -> argparse.ArgumentParser:
    """Build the documented public command-line interface."""

    parser = argparse.ArgumentParser(
        prog="nitroxai",
        description=(
            "Residue-level S-nitrosylation prediction with frozen NitroXAI 0.1.1. "
            "Inputs are complete proteins, not pre-extracted windows."
        ),
    )
    parser.add_argument("--version", action="version", version=f"nitroxai {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    info = subparsers.add_parser("info", help="show frozen model and environment information")
    _add_device_argument(info)

    predict = subparsers.add_parser("predict", help="predict one cysteine or scan all cysteines")
    _add_input_arguments(predict)
    predict.add_argument("--position", type=int, help="1-based cysteine position; otherwise scan all C sites")
    predict.add_argument("--protein-id", default="sequence", help="ID for --sequence input")
    _add_output_arguments(predict)
    _add_device_argument(predict)
    predict.add_argument(
        "--fold-probabilities", action="store_true", help="include all five fold probabilities"
    )
    predict.add_argument(
        "--context", action="store_true", help="include sequence length and X-padded sequence window"
    )

    batch = subparsers.add_parser("batch", help="process a multi-record FASTA or UniProt accession list")
    source = batch.add_mutually_exclusive_group(required=True)
    source.add_argument("--fasta", help="input FASTA with one or more complete proteins")
    source.add_argument("--accessions", help="text file containing one UniProt accession per line")
    batch.add_argument("--output", required=True, help="prediction output path")
    batch.add_argument("--format", choices=("table", "csv", "json"), default="csv")
    _add_device_argument(batch)
    batch.add_argument(
        "--fold-probabilities", action="store_true", help="include all five fold probabilities"
    )
    batch.add_argument(
        "--context", action="store_true", help="include sequence length and X-padded sequence window"
    )

    explain = subparsers.add_parser("explain", help="explain one cysteine with notebook-parity IG")
    _add_input_arguments(explain)
    explain.add_argument("--position", type=int, required=True, help="1-based cysteine position")
    explain.add_argument("--protein-id", default="sequence", help="ID for --sequence input")
    _add_output_arguments(explain)
    _add_device_argument(explain)
    explain.add_argument(
        "--attention", action="store_true", help="also include learned ESM attention weights (not IG)"
    )
    return parser


def _add_input_arguments(parser: argparse.ArgumentParser) -> None:
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--sequence", help="raw complete amino-acid sequence")
    inputs.add_argument("--fasta", help="input FASTA file")
    inputs.add_argument("--uniprot", help="UniProt accession to retrieve")


def _add_output_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--format",
        choices=("table", "csv", "json"),
        default=None,
        help=(
            "output format; defaults to a table on stdout, or is inferred from a "
            ".csv/.json --output path"
        ),
    )
    parser.add_argument(
        "--output",
        help="file to create; without it, output is written to the terminal",
    )


def _add_device_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")


def _prediction_rows(
    results: Sequence[PredictionResult], *, include_fold_probabilities: bool, include_context: bool
) -> list[dict[str, object]]:
    return [
        result.to_dict(
            include_fold_probabilities=include_fold_probabilities,
            include_context=include_context,
        )
        for result in results
    ]


def _resolved_output_format(output_format: str | None, output: str | None) -> str:
    """Choose an intuitive file format while preserving the terminal table default."""

    if output_format is not None:
        return output_format
    if output is not None:
        return {".csv": "csv", ".json": "json"}.get(Path(output).expanduser().suffix.lower(), "table")
    return "table"


def _emit(rows: list[dict[str, object]], output_format: str | None, output: str | None) -> None:
    output_format = _resolved_output_format(output_format, output)
    if output is None:
        sys.stdout.write(render_rows(rows, output_format))
        return
    write_rows(output, rows, output_format)
    print(f"Wrote {len(rows)} rows to {Path(output).expanduser()}")


def _predict_from_input(args: argparse.Namespace, predictor: NitroXAIPredictor) -> list[PredictionResult]:
    if args.sequence is not None:
        if args.position is not None:
            return [
                predictor.predict_site(
                    args.sequence,
                    args.position,
                    protein_id=args.protein_id,
                    include_fold_probabilities=args.fold_probabilities,
                )
            ]
        return predictor.predict_sequence(
            args.sequence,
            protein_id=args.protein_id,
            include_fold_probabilities=args.fold_probabilities,
        )
    if args.uniprot is not None:
        if args.position is not None:
            return [
                predictor.predict_uniprot_site(
                    args.uniprot, args.position, include_fold_probabilities=args.fold_probabilities
                )
            ]
        return predictor.predict_uniprot(args.uniprot, include_fold_probabilities=args.fold_probabilities)
    records = read_fasta(args.fasta)
    if args.position is not None:
        if len(records) != 1:
            raise NitroXAIError("--position with --fasta requires exactly one FASTA record.")
        record = records[0]
        return [
            predictor.predict_site(
                record.sequence,
                args.position,
                protein_id=record.identifier,
                include_fold_probabilities=args.fold_probabilities,
            )
        ]
    return predictor.predict_batch(records, include_fold_probabilities=args.fold_probabilities)


def _run_predict(args: argparse.Namespace) -> int:
    predictor = NitroXAIPredictor(device=args.device)
    results = _predict_from_input(args, predictor)
    _emit(
        _prediction_rows(
            results,
            include_fold_probabilities=args.fold_probabilities,
            include_context=args.context,
        ),
        args.format,
        args.output,
    )
    return 0


def _read_accessions(path: str) -> list[str]:
    accession_path = Path(path).expanduser()
    if not accession_path.is_file():
        raise NitroXAIError("Accession-list path does not exist or is not a file.")
    try:
        values = [line.strip() for line in accession_path.read_text(encoding="utf-8").splitlines()]
    except OSError as exc:
        raise NitroXAIError("Unable to read accession-list input file.") from exc
    accessions = [value for value in values if value and not value.startswith("#")]
    if not accessions:
        raise NitroXAIError("Accession-list input contains no accessions.")
    return accessions


def _batch_status_row(protein_id: str, status: str, error: str | None = None) -> dict[str, object]:
    return {
        "protein_id": protein_id,
        "position": None,
        "residue": None,
        "probability": None,
        "prediction": None,
        "prediction_binary": None,
        "threshold": FINAL_THRESHOLD,
        "status": status,
        "error": error,
    }


def _run_batch(args: argparse.Namespace) -> int:
    predictor = NitroXAIPredictor(device=args.device)
    rows: list[dict[str, object]] = []
    if args.fasta is not None:
        for record in read_fasta(args.fasta):
            try:
                results = predictor.predict_sequence(
                    record.sequence,
                    protein_id=record.identifier,
                    include_fold_probabilities=args.fold_probabilities,
                )
                if results:
                    for row in _prediction_rows(
                        results,
                        include_fold_probabilities=args.fold_probabilities,
                        include_context=args.context,
                    ):
                        row.update({"status": "ok", "error": None})
                        rows.append(row)
                else:
                    rows.append(_batch_status_row(record.identifier, "no_cysteines"))
            except NitroXAIError as exc:
                rows.append(_batch_status_row(record.identifier, "error", str(exc)))
    else:
        for accession in _read_accessions(args.accessions):
            try:
                results = predictor.predict_uniprot(
                    accession, include_fold_probabilities=args.fold_probabilities
                )
                if results:
                    for row in _prediction_rows(
                        results,
                        include_fold_probabilities=args.fold_probabilities,
                        include_context=args.context,
                    ):
                        row.update({"status": "ok", "error": None})
                        rows.append(row)
                else:
                    rows.append(_batch_status_row(accession, "no_cysteines"))
            except NitroXAIError as exc:
                rows.append(_batch_status_row(accession, "error", str(exc)))
    _emit(rows, args.format, args.output)
    return 0


def _run_explain(args: argparse.Namespace) -> int:
    predictor = NitroXAIPredictor(device=args.device)
    if args.sequence is not None:
        explanation = predictor.explain_site(
            args.sequence,
            args.position,
            protein_id=args.protein_id,
            include_attention=args.attention,
        )
    elif args.uniprot is not None:
        explanation = predictor.explain_uniprot_site(
            args.uniprot, args.position, include_attention=args.attention
        )
    else:
        records = read_fasta(args.fasta)
        if len(records) != 1:
            raise NitroXAIError("explain --fasta requires exactly one FASTA record.")
        record = records[0]
        explanation = predictor.explain_site(
            record.sequence,
            args.position,
            protein_id=record.identifier,
            include_attention=args.attention,
        )
    _emit(explanation.to_rows(include_attention=args.attention), args.format, args.output)
    return 0


def _run_info(args: argparse.Namespace) -> int:
    predictor = NitroXAIPredictor(device=args.device, verify_artifacts=True)
    environment = esm_environment()
    model = build_model()
    print(f"NitroXAI version: {__version__}")
    print("Model: NitroXAI")
    print(f"ESM backbone: {ESM_MODEL_NAME}")
    print(f"ESM representation dimension: {ESM_EMBED_DIM}")
    print(f"ESM representation layer: {ESM_LAYER}")
    print("ESM parameters: frozen")
    print("ESM input: complete cleaned protein, encoded before 61-residue extraction")
    print(f"Window size: {WINDOW_SIZE}")
    print(f"Handcrafted channels: {HANDCRAFTED_CHANNELS}")
    print("Handcrafted representation: 128")
    print("ESM pooled representation: 640")
    print("Fusion representation: 768")
    print(f"Ensemble folds: {N_FOLDS}")
    print(f"Decision threshold: {FINAL_THRESHOLD!r}")
    print(f"Trainable downstream parameters: {trainable_parameter_count(model)}")
    print("Integrated Gradients: available (manual notebook-parity, 32 steps)")
    print(f"Device: {predictor.device}")
    print(f"PyTorch: {torch.__version__}")
    print(f"ESM library: {environment['package_name']} {environment['package_version']}")
    if trainable_parameter_count(model) != MODEL_PARAMETER_COUNT:
        raise RuntimeError("The packaged model architecture has an invalid parameter count.")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI without exposing expected user errors as tracebacks."""

    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0
    try:
        if args.command == "info":
            return _run_info(args)
        if args.command == "predict":
            return _run_predict(args)
        if args.command == "batch":
            return _run_batch(args)
        if args.command == "explain":
            return _run_explain(args)
        parser.error(f"unknown command: {args.command}")
    except (NitroXAIError, OSError, ValueError) as exc:
        print(f"nitroxai: error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("nitroxai: interrupted", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"nitroxai: error: {exc}", file=sys.stderr)
        return 1
    return 0
