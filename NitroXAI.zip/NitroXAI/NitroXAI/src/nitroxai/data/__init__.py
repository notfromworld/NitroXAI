"""Bundled frozen NitroXAI checkpoints, scalers, and configuration."""
