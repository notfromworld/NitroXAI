"""Validated fair-esm loading and full-protein ESM-2 representation extraction."""

from __future__ import annotations

from importlib import metadata
from typing import Any, Callable

import numpy as np
import torch

from .constants import (
    ESM_EMBED_DIM,
    ESM_IMPORT_NAME,
    ESM_LAYER,
    ESM_MODEL_NAME,
    ESM_PACKAGE_NAME,
    ESM_PACKAGE_VERSION,
)
from .exceptions import ESMError
from .sequence import clean_sequence


ModelLoader = Callable[[str], tuple[torch.nn.Module, Any]]


class ESMBackbone:
    """One lazy, frozen fair-esm ESM-2 150M backbone per predictor instance.

    No downstream fold owns an ESM copy.  ``embed_full`` always tokenizes and
    encodes the complete cleaned protein exactly once per call, then removes
    the BOS representation with ``[0, 1:n + 1]``.  It deliberately implements
    no window-level encoding, truncation, or chunking fallback.
    """

    def __init__(self, device: torch.device, *, loader: ModelLoader | None = None) -> None:
        self.device = torch.device(device)
        self._loader = loader
        self._model: torch.nn.Module | None = None
        self._alphabet: Any | None = None
        self._batch_converter: Any | None = None
        self._layer: int | None = None
        self._embed_dim: int | None = None
        self.encode_calls = 0

    @property
    def model(self) -> torch.nn.Module:
        """Return the loaded frozen backbone, loading it only when needed."""

        self.load()
        assert self._model is not None
        return self._model

    @property
    def layer(self) -> int:
        self.load()
        assert self._layer is not None
        return self._layer

    @property
    def embed_dim(self) -> int:
        self.load()
        assert self._embed_dim is not None
        return self._embed_dim

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def load(self) -> None:
        """Load canonical cached/downloadable weights through fair-esm only."""

        if self._model is not None:
            return
        try:
            import esm
        except Exception as exc:
            raise ESMError(
                "NitroXAI requires the validated fair-esm package (import esm, version 2.0.0)."
            ) from exc
        try:
            installed_version = metadata.version(ESM_PACKAGE_NAME)
        except metadata.PackageNotFoundError as exc:
            raise ESMError(
                "NitroXAI requires the validated fair-esm package (version 2.0.0)."
            ) from exc
        module_version = str(getattr(esm, "__version__", installed_version))
        if installed_version != ESM_PACKAGE_VERSION or module_version != ESM_PACKAGE_VERSION:
            raise ESMError(
                f"NitroXAI requires {ESM_PACKAGE_NAME}=={ESM_PACKAGE_VERSION}; "
                f"found package {installed_version!r} and module {module_version!r}."
            )
        try:
            loader = self._loader or esm.pretrained.load_model_and_alphabet
            model, alphabet = loader(ESM_MODEL_NAME)
        except Exception as exc:
            raise ESMError(
                "The pretrained ESM-2 150M weights required by NitroXAI are not available "
                "locally and could not be retrieved."
            ) from exc
        try:
            model = model.to(self.device).eval()
            for parameter in model.parameters():
                parameter.requires_grad_(False)
            layer = int(model.num_layers)
            embed_dim = int(model.embed_dim)
            if layer != ESM_LAYER:
                raise ESMError(f"Expected ESM representation layer {ESM_LAYER}, found {layer}.")
            if embed_dim != ESM_EMBED_DIM:
                raise ESMError(f"Expected ESM embedding dimension {ESM_EMBED_DIM}, found {embed_dim}.")
            batch_converter = alphabet.get_batch_converter()
        except ESMError:
            raise
        except Exception as exc:
            raise ESMError("The loaded ESM model does not provide the validated fair-esm interface.") from exc
        self._model = model
        self._alphabet = alphabet
        self._batch_converter = batch_converter
        self._layer = layer
        self._embed_dim = embed_dim

    def embed_full(self, sequence: str) -> np.ndarray:
        """Encode one full cleaned protein and return ``[length, 640]`` float32.

        The output excludes the ESM BOS and EOS positions, as verified from the
        exact Cell-2 slice.  An ESM memory failure is surfaced; no scientific
        fallback to fragments, truncation, or chunking is permitted.
        """

        sequence = clean_sequence(sequence, allow_empty=True)
        length = len(sequence)
        if length == 0:
            return np.zeros((0, ESM_EMBED_DIM), dtype=np.float32)
        self.load()
        assert self._model is not None
        assert self._batch_converter is not None
        assert self._layer is not None
        try:
            _, _, tokens = self._batch_converter([("protein", sequence)])
            tokens = tokens.to(self.device)
            with torch.inference_mode():
                output = self._model(
                    tokens,
                    repr_layers=[self._layer],
                    return_contacts=False,
                )
        except RuntimeError as exc:
            if "out of memory" in str(exc).lower():
                if self.device.type == "cuda":
                    torch.cuda.empty_cache()
                raise ESMError(
                    f"FULL ESM protocol ran out of memory for a protein of {length:,} residues. "
                    "No truncation or chunk fallback was applied."
                ) from exc
            raise ESMError(
                f"FULL ESM protocol could not encode a protein of {length:,} residues. "
                "No truncation or chunk fallback was applied."
            ) from exc
        try:
            representation = (
                output["representations"][self._layer][0, 1 : length + 1]
                .detach()
                .float()
                .cpu()
                .numpy()
                .astype(np.float32, copy=False)
            )
        finally:
            del tokens, output
        expected = (length, ESM_EMBED_DIM)
        if representation.shape != expected:
            raise ESMError(f"FULL ESM shape mismatch: {representation.shape} != {expected}.")
        if not np.isfinite(representation).all():
            raise ESMError("FULL ESM embedding contains NaN/Inf.")
        self.encode_calls += 1
        return representation


def extract_esm_window(
    esm_embedding: np.ndarray,
    protein_length: int,
    position0: int,
    half_window: int = 30,
) -> np.ndarray:
    """Extract the notebook's zero-padded 61 x 640 contextual ESM window."""

    protein_length = int(protein_length)
    position0 = int(position0)
    window_length = 2 * half_window + 1
    embedding = np.asarray(esm_embedding, dtype=np.float32)
    if embedding.shape != (protein_length, ESM_EMBED_DIM):
        raise ValueError(
            f"Protein ESM shape {embedding.shape} does not match {(protein_length, ESM_EMBED_DIM)}."
        )
    output = np.zeros((window_length, ESM_EMBED_DIM), dtype=np.float32)
    left = position0 - half_window
    for index in range(window_length):
        sequence_position = left + index
        if 0 <= sequence_position < protein_length:
            output[index] = embedding[sequence_position]
    return output


def esm_environment() -> dict[str, str]:
    """Return provenance needed by ``nitroxai info`` without loading weights."""

    try:
        import esm

        module_path = str(getattr(esm, "__file__", ""))
        module_version = str(getattr(esm, "__version__", "unknown"))
    except Exception:
        module_path = "unavailable"
        module_version = "unavailable"
    try:
        package_version = metadata.version(ESM_PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        package_version = "unavailable"
    return {
        "import_name": ESM_IMPORT_NAME,
        "package_name": ESM_PACKAGE_NAME,
        "package_version": package_version,
        "module_version": module_version,
        "module_path": module_path,
        "model": ESM_MODEL_NAME,
    }
