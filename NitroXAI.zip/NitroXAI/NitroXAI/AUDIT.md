# NitroXAI final-notebook audit

Authoritative source inspected: `NitroXAI_ESM61_FINAL_COMPLETE.ipynb`, whose
metadata selects `Python (NitroXAI CV)` / `nitroxai_cv`. This audit follows the
notebook's final artifact paths rather than earlier NitroXAI, chunked-ESM,
window-57/65, or SNO-CLIM artifacts elsewhere in the workspace.

## Final scientific definition

The final runtime definition is Cell 2 plus the frozen Cell-4 artifacts:

```text
clean full protein
  -> fair-esm esm2_t30_150M_UR50D, frozen/eval, layer 30
  -> remove BOS/EOS and retain one 640-vector per real residue
  -> extract zero-padded ±30 ESM window for each cysteine
  -> construct X-padded ±30 handcrafted 27-channel window
  -> apply the matching saved fold scalers (including sqrt(dim) denominators)
  -> downstream attention_esm fold logit -> sigmoid
  -> arithmetic mean of five probabilities -> frozen threshold
```

Cell 4 stores only downstream weights. It does not store five ESM backbones;
the package correctly keeps one shared frozen fair-esm backbone.

## Cell-by-cell audit

| Notebook cell / definition | Final or obsolete | Package destination | Artifact dependency | Verified behavior |
| --- | --- | --- | --- | --- |
| 0–1 markdown | Final context | Documentation | none | Declares final reproducible human pipeline. |
| 2 / Cell 1 | Final cohort construction | Audit only | `filtered_cysteine_summary.csv`, `clustered.fasta` | `clean_seq`: uppercase/remove whitespace; noncanonical symbols become X with length preserved. Sites are 1-based input / 0-based internal. Not required for package inference. |
| 4 / Cell 2 §§3–7 | **Final runtime** | `sequence.py`, `esm.py`, `handcrafted.py` | fair-esm weights | `esm.pretrained.load_model_and_alphabet("esm2_t30_150M_UR50D")`; eval/frozen; layer 30, dim 640; `[0, 1:n+1]`; full protein before extraction; no manual truncate/chunk; ESM terminal padding is zero vectors. |
| 4 / Cell 2 §6–7 | **Final runtime** | `constants.py`, `handcrafted.py` | none | 61 x 27 features, X padding, hydropathy values, D/E acidic, K/R/H basic, C channel, `P -> exp(-abs(rel)/1)`, `rel/30`, `exp(-abs(rel)/10)`. |
| 4 / Cell 2 §8 | **Final runtime** | `model.py`, `attention.py` | five checkpoints | Conv(27,64,k3), BN/ReLU/dropout; Conv(64,128,k5), BN/ReLU/dropout; BiLSTM(128,64 bidirectional), max pool; `Linear(640,1)(tanh(esm))`, softmax over 61, weighted sum; 128+640 -> 64 -> 1 raw logit. |
| 4 / Cell 2 §9 | Final training/audit helper | configuration/docs only | OOF artifacts | Contains metric and exact-MCC helper. The final operating policy is chosen in Cell 4, not recomputed by the package. |
| 6 / Cell 3 | Final cache builder | runtime logic and tests | development raw caches (not bundled) | Builds handcrafted and full-ESM caches per protein, then reuses each protein embedding for every cysteine. Cache is training support only; no data cache is bundled. |
| 8 / Cell 4 §§1–8 | Final training protocol | `preprocessing.py`, `ensemble.py` | checkpoint/scaler pairs | Fits seven handcrafted and one ESM StandardScaler on each fold's training data. Inference uses saved means/scales and an extra `sqrt(head_dim)` / `sqrt(640)` denominator. No inference fitting. |
| 8 / Cell 4 §§9–10 | Final OOF threshold | `constants.py`, `config` | OOF summary | Five fold probabilities are averaged. Threshold is development OOF-only, within 0.01 MCC of the maximum then minimum `|SN-SP|`, yielding `0.5757167935371399`; it is frozen. |
| 8 / Cell 4 §§11–16 | Final independent test | parity report/tests | test raw caches and frozen outputs (not bundled) | Test access happens after threshold freeze; saved metrics use five-probability mean. No retraining, calibration, or test threshold tuning. |
| 10 / Cell 5 | Final artifact freeze | `data/`, manifests | frozen SHA CSV/JSON | Strictly identifies five `nitroxai_esm61_protocol_compare/full` checkpoints and matching scalers. These, not any SNO-CLIM or chunked artifacts, are packaged. |
| 12 / Cell 6 | Final figure rendering | report only | frozen OOF/test predictions | Plotting only; no model behavior. |
| 14 / Cell 7 | **Final IG definition** | `interpretability.py` | checkpoints/scalers and raw inputs | Manual 32-point right-Riemann IG, model logit target, zero baseline in standardized space, cuDNN disabled around IG gradient, fold-specific scaling, signed/absolute position sums and modality `sum(abs(IG))`. |
| 16 / Cell 8 | Final IG analysis | `interpretability.py`, report | saved IG arrays | Five-fold arithmetic mean of raw attributions. Modality fractions are derived from fold-mean absolute modality totals. Its display-only normalization is not used by the package. |
| 18 / Cell 9 | Final external-cache workflow, not human runtime | documentation only | cross-species raw cache | Reuses Cell-2 full ESM behavior. Its `<=5000` common-cohort rule is evaluation-subset policy, not a package truncation algorithm. |
| 20 / Cell 10 | Final external inference, not package runtime | documentation only | frozen human folds/scalers | Confirms exact same fold assets and frozen human threshold are used externally. |
| 22 / Cell 11 | Final external metrics | documentation only | saved external predictions | Metrics only; asserts frozen threshold. |
| 24 / Cell 12 | Final homology analysis | documentation only | saved BLAST mappings/predictions | No package inference or model mutation. |
| 26 / Cell 13 | Final NitroXAI/SNO-CLIM comparison | documentation only | frozen final outputs | Comparison/export only; no retraining, threshold selection, or inference. |
| 27 | Final publication-figure script | documentation only | frozen prediction CSVs | Reads saved probabilities/thresholds only. |
| 28 | Auxiliary OOF alignment diagnostic | Obsolete for runtime | none | Diagnostic uses Cell-27 variables; has no model, scaler, threshold, or inference definition. |
| 29 | Empty code cell | Obsolete | none | No behavior. |

## Artifact mapping

| Final notebook source | Packaged destination | Status |
| --- | --- | --- |
| `nitroxai_esm61_protocol_compare/full/checkpoints/fold_{1..5}_window61.pt` | `src/nitroxai/data/checkpoints/` | packaged byte-for-byte; SHA-256 verified |
| `nitroxai_esm61_protocol_compare/full/scalers/fold_{1..5}_window61_scalers.joblib` | `src/nitroxai/data/scalers/` | packaged byte-for-byte; SHA-256 verified |
| Cell-4 OOF summary/Cell-5 freeze metadata | `data/config/model_config.json`, reproducibility reports | frozen threshold/protocol encoded; prediction datasets not bundled |
| canonical fair-esm ESM-2 150M weights | fair-esm/PyTorch cache | intentionally not bundled; exact loader/version pinned |

All checksums and paths are recorded in
`reproducibility/artifact_manifest.csv`.

## Discrepancies resolved by source-of-truth priority

1. The final model's Cell-2 implementation internally receives a concatenated
   61 x 667 tensor. The package public model accepts parallel 61 x 27 and
   61 x 640 inputs while preserving the exact module names, equations, and a
   legacy 667 input path for direct checkpoint/notebook parity. This is an API
   representation, not an architectural redesign.
2. ESM **is** fold-scaled in final Cell 4: saved `esm_scaler` statistics are
   applied and divided by `sqrt(640)`. It is not left unscaled.
3. Captum is absent from the authoritative environment and final Cell 7 does
   not call it. The package reproduces the manual implementation rather than
   introducing Captum behavior.
4. The final human protocol has no manual length cutoff, truncation, or
   chunking. It validates full proteins up to 4,857 residues in the human
   cohort; the unrelated external common-cohort `<=5000` filter is documented
   but not applied as a runtime fallback.
5. Terminal ESM zero vectors are created before fold scaling. Consequently,
   their standardized downstream values are generally nonzero; replacing them
   with post-scaling zero values would be scientifically incorrect.
6. The final threshold is near-optimal MCC balancing, not the Cell-2 exact-MCC
   helper's `0.6744776368141174` threshold.
