"""Read and validate frozen package configuration."""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

from .constants import FINAL_THRESHOLD, HALF_WINDOW, INPUT_CHANNELS, N_FOLDS, WINDOW_SIZE
from .exceptions import ArtifactError
from .utils import package_data_text


@lru_cache(maxsize=1)
def load_model_config() -> dict[str, Any]:
    """Return the bundled, notebook-derived model metadata."""

    config = json.loads(package_data_text("config/model_config.json"))
    if int(config.get("window_length", -1)) != WINDOW_SIZE:
        raise ArtifactError("Packaged model configuration has an invalid window length.")
    if int(config.get("features", {}).get("handcrafted_channels", -1)) != INPUT_CHANNELS:
        raise ArtifactError("Packaged model configuration has an invalid channel count.")
    if int(config.get("cv", "").split("-")[0]) != N_FOLDS:
        raise ArtifactError("Packaged model configuration has an invalid fold count.")
    if float(config.get("threshold", float("nan"))) != FINAL_THRESHOLD:
        raise ArtifactError("Packaged model configuration has an invalid frozen threshold.")
    if int(config.get("window_length", 0)) != 2 * HALF_WINDOW + 1:
        raise ArtifactError("Packaged model configuration is internally inconsistent.")
    return config


@lru_cache(maxsize=1)
def load_asset_manifest() -> dict[str, Any]:
    """Return checksums for resources bundled with this distribution."""

    return json.loads(package_data_text("config/package_artifact_manifest.json"))
