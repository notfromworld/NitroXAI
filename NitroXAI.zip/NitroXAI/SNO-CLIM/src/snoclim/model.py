"""The exact frozen CNN-BiLSTM architecture used by SNO-CLIM."""

from __future__ import annotations

import torch
from torch import nn

from .constants import DROPOUT, INPUT_CHANNELS, MODEL_PARAMETER_COUNT


class CNNBiLSTM(nn.Module):
    """Notebook-parity CNN-BiLSTM classifier returning an uncalibrated logit."""

    def __init__(self, in_channels: int = INPUT_CHANNELS, dropout: float = DROPOUT) -> None:
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(in_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(64, 128, kernel_size=5, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(
            input_size=128,
            hidden_size=64,
            batch_first=True,
            bidirectional=True,
        )
        self.head = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Accept ``[batch, length, channels]`` and return raw logits."""

        x = x.permute(0, 2, 1)
        x = self.cnn(x)
        x = x.permute(0, 2, 1)
        x, _ = self.lstm(x)
        x = x.max(dim=1).values
        return self.head(x).squeeze(-1)


def trainable_parameter_count(model: nn.Module) -> int:
    """Count trainable parameters, used to guard architecture parity."""

    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)


def assert_expected_parameter_count(model: nn.Module) -> None:
    """Fail early if an accidental architecture change occurred."""

    count = trainable_parameter_count(model)
    if count != MODEL_PARAMETER_COUNT:
        raise RuntimeError(
            f"Unexpected SNO-CLIM parameter count: {count} != {MODEL_PARAMETER_COUNT}."
        )
