"""Notebook-parity Integrated Gradients for an individual SNO-CLIM site."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np
import torch
from torch import nn

from .constants import CHANNEL_SLICES, HALF_WINDOW, IG_STEPS, N_FOLDS
from .ensemble import FoldArtifact
from .features import encode_windows, get_window
from .preprocessing import transform_heads_with_fitted_scalers


@dataclass(frozen=True)
class ResidueAttribution:
    """Raw ensemble Integrated Gradients aggregated at one window position."""

    position: int | None
    relative_position: int
    residue: str
    signed_ig: float
    absolute_ig: float
    feature_attributions: dict[str, dict[str, float]] | None = None

    def to_dict(self, *, detailed: bool = False) -> dict[str, object]:
        row: dict[str, object] = {
            "position": self.position,
            "relative_position": self.relative_position,
            "residue": self.residue,
            "signed_ig": self.signed_ig,
            "absolute_ig": self.absolute_ig,
        }
        if detailed and self.feature_attributions is not None:
            for name, values in self.feature_attributions.items():
                row[f"{name}_signed_ig"] = values["signed_ig"]
                row[f"{name}_absolute_ig"] = values["absolute_ig"]
        return row


@dataclass(frozen=True)
class SiteExplanation:
    """Notebook-parity explanation metadata and all 61 residue attributions."""

    protein_id: str
    target_position: int
    target_residue: str
    window_sequence: str
    ig_steps: int
    baseline: str
    target: str
    rows: tuple[ResidueAttribution, ...]

    def to_rows(self, *, detailed: bool = False) -> list[dict[str, object]]:
        """Convert the residue-level output to JSON/CSV/table-friendly mappings."""

        return [row.to_dict(detailed=detailed) for row in self.rows]


def prepare_model_for_ig(model: nn.Module) -> nn.Module:
    """Replicate the final notebook's cuDNN-safe IG model state exactly."""

    model.train()
    for module in model.modules():
        if isinstance(module, nn.Dropout):
            module.eval()
        elif isinstance(module, nn.BatchNorm1d):
            module.eval()
    return model


def integrated_gradients(
    model: nn.Module,
    x: torch.Tensor,
    *,
    device: torch.device,
    steps: int = IG_STEPS,
) -> np.ndarray:
    """Use the final notebook's right-Riemann, zero-baseline IG calculation.

    It intentionally targets the pre-sigmoid logit and does not normalize the
    raw attribution values.  This is not a replacement with Captum; Captum was
    not installed or used by the authoritative final notebook.
    """

    if steps != IG_STEPS:
        raise ValueError(f"Notebook-parity Integrated Gradients requires exactly {IG_STEPS} steps.")
    model = prepare_model_for_ig(model)
    x = x.unsqueeze(0).to(device)
    baseline = torch.zeros_like(x)
    gradient_sum = torch.zeros_like(x)
    alphas = torch.linspace(1.0 / steps, 1.0, steps, device=device)
    with torch.enable_grad():
        for alpha in alphas:
            interpolated = (baseline + alpha * (x - baseline)).detach().requires_grad_(True)
            model.zero_grad(set_to_none=True)
            logit = model(interpolated).reshape(-1).sum()
            gradient = torch.autograd.grad(
                logit,
                interpolated,
                retain_graph=False,
                create_graph=False,
            )[0]
            gradient_sum += gradient.detach()
    return ((x - baseline) * (gradient_sum / float(steps))).squeeze(0).detach().cpu().numpy()


def _feature_groups(
    signed_channels: np.ndarray,
    absolute_channels: np.ndarray,
) -> dict[str, dict[str, float]]:
    result: dict[str, dict[str, float]] = {}
    labels = {
        "aa": "aa_onehot",
        "hydro": "hydropathy",
        "acid": "acidic",
        "base": "basic",
        "cys": "cysteine",
        "pro": "proline",
        "dist": "distance",
    }
    for head, output_name in labels.items():
        channel_slice = CHANNEL_SLICES[head]
        result[output_name] = {
            "signed_ig": float(signed_channels[channel_slice].sum()),
            "absolute_ig": float(absolute_channels[channel_slice].sum()),
        }
    return result


def explain_site(
    *,
    folds: Iterable[FoldArtifact],
    device: torch.device,
    sequence: str,
    position0: int,
    protein_id: str,
    detailed: bool = False,
) -> SiteExplanation:
    """Calculate all 61 raw residue attributions for one validated cysteine."""

    fold_list = list(folds)
    if len(fold_list) != N_FOLDS:
        raise RuntimeError(f"Expected {N_FOLDS} loaded folds for Integrated Gradients.")

    raw_heads = encode_windows(sequence, [position0], HALF_WINDOW)
    fold_attributions: list[np.ndarray] = []
    for artifact in fold_list:
        transformed = transform_heads_with_fitted_scalers(raw_heads, artifact.scalers)
        attribution = integrated_gradients(
            artifact.model,
            torch.tensor(transformed[0], dtype=torch.float32),
            device=device,
            steps=IG_STEPS,
        )
        fold_attributions.append(attribution.astype(np.float32, copy=False))
        artifact.model.eval()

    all_attributions = np.stack(fold_attributions, axis=0)
    # These two reductions exactly match the final notebook's fold_signed and
    # fold_abs construction followed by its five-fold arithmetic mean.
    fold_signed = all_attributions.sum(axis=-1)
    fold_absolute = np.abs(all_attributions).sum(axis=-1)
    ensemble_signed = fold_signed.mean(axis=0)
    ensemble_absolute = fold_absolute.mean(axis=0)
    mean_signed_channels = all_attributions.mean(axis=0)
    mean_absolute_channels = np.abs(all_attributions).mean(axis=0)

    window = get_window(sequence, position0, HALF_WINDOW)
    rows: list[ResidueAttribution] = []
    for index, residue in enumerate(window):
        relative_position = index - HALF_WINDOW
        sequence_index = position0 + relative_position
        position = sequence_index + 1 if 0 <= sequence_index < len(sequence) else None
        rows.append(
            ResidueAttribution(
                position=position,
                relative_position=relative_position,
                residue=residue,
                signed_ig=float(ensemble_signed[index]),
                absolute_ig=float(ensemble_absolute[index]),
                feature_attributions=(
                    _feature_groups(mean_signed_channels[index], mean_absolute_channels[index])
                    if detailed
                    else None
                ),
            )
        )

    return SiteExplanation(
        protein_id=protein_id,
        target_position=position0 + 1,
        target_residue=sequence[position0],
        window_sequence=window,
        ig_steps=IG_STEPS,
        baseline="zero vector in each fold-standardized input space",
        target="pre-sigmoid model logit",
        rows=tuple(rows),
    )
