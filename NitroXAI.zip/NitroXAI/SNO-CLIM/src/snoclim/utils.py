"""Internal helpers that do not affect the scientific inference path."""

from __future__ import annotations

from contextlib import contextmanager
from hashlib import sha256
from importlib import resources
from pathlib import Path
from typing import Iterator

import torch

from .exceptions import ArtifactError, SNOCLIMError


@contextmanager
def package_data_path(relative_path: str) -> Iterator[Path]:
    """Yield a filesystem path for a packaged asset without using ``cwd``.

    ``importlib.resources.as_file`` also works when package data is supplied by
    an importer that does not expose regular on-disk files.
    """

    resource = resources.files("snoclim.data").joinpath(relative_path)
    if not resource.is_file():
        raise ArtifactError(f"Required packaged model asset is missing: {relative_path}")
    with resources.as_file(resource) as path:
        yield Path(path)


def package_data_text(relative_path: str) -> str:
    """Read a UTF-8 package asset."""

    resource = resources.files("snoclim.data").joinpath(relative_path)
    if not resource.is_file():
        raise ArtifactError(f"Required packaged model asset is missing: {relative_path}")
    return resource.read_text(encoding="utf-8")


def sha256_file(path: Path) -> str:
    """Calculate a file digest in bounded memory."""

    digest = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_device(requested: str | torch.device = "auto") -> torch.device:
    """Resolve the documented ``auto``, ``cpu``, or ``cuda`` device choice."""

    if isinstance(requested, torch.device):
        device = requested
    else:
        value = str(requested).strip().lower()
        if value == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if value == "cpu":
            return torch.device("cpu")
        if value == "cuda":
            device = torch.device("cuda")
        elif value.startswith("cuda:"):
            device = torch.device(value)
        else:
            raise SNOCLIMError("Device must be one of: auto, cpu, cuda.")

    if device.type == "cuda" and not torch.cuda.is_available():
        raise SNOCLIMError("CUDA was requested, but no CUDA device is available.")
    if device.type not in {"cpu", "cuda"}:
        raise SNOCLIMError("Device must be one of: auto, cpu, cuda.")
    if device.type == "cuda":
        # Establish the primary context before an Integrated Gradients backward
        # pass. This changes no tensor math and avoids PyTorch's first-cuBLAS
        # context warning on otherwise valid CUDA installations.
        torch.cuda.init()
    return device
