"""Frozen fold-specific scaler application for SNO-CLIM inference."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import numpy as np

from .constants import HEAD_DIMS, HEADS, INPUT_CHANNELS
from .exceptions import ArtifactError


def validate_scaler_bundle(scalers: Mapping[str, Any]) -> None:
    """Verify the serialized fold object has the expected seven fitted scalers."""

    if set(scalers) != set(HEADS):
        raise ArtifactError(
            "Scaler heads do not match the frozen model: "
            f"expected {list(HEADS)}, got {sorted(scalers)}."
        )
    for head in HEADS:
        scaler = scalers[head]
        if not hasattr(scaler, "transform") or not hasattr(scaler, "mean_"):
            raise ArtifactError(f"Scaler for head '{head}' is not a fitted StandardScaler.")
        expected = HEAD_DIMS[head]
        if int(getattr(scaler, "n_features_in_", expected)) != expected:
            raise ArtifactError(f"Scaler for head '{head}' has unexpected feature dimension.")
        if np.asarray(scaler.mean_).shape != (expected,):
            raise ArtifactError(f"Scaler for head '{head}' has unexpected saved statistics.")


def transform_heads_with_fitted_scalers(
    heads: Mapping[str, np.ndarray],
    scalers: Mapping[str, Any],
) -> np.ndarray:
    """Apply one fold's saved scalers without ever fitting on inference data.

    This preserves the final notebook order exactly: flatten the site/window
    dimensions, call each head's saved ``transform``, reshape, divide by the
    square root of that head dimension, then concatenate in ``HEADS`` order.
    """

    validate_scaler_bundle(scalers)
    transformed_parts: list[np.ndarray] = []
    for head in HEADS:
        if head not in heads:
            raise KeyError(f"Missing raw feature head '{head}'.")
        raw = np.asarray(heads[head])
        if raw.ndim != 3 or raw.shape[-1] != HEAD_DIMS[head]:
            raise ValueError(
                f"Raw head '{head}' must have shape [sites, window, {HEAD_DIMS[head]}]."
            )
        flattened = raw.reshape(-1, raw.shape[-1])
        scaled = scalers[head].transform(flattened).reshape(raw.shape)
        # Use NumPy's scalar operation exactly as in the final notebook rather
        # than a mathematically equivalent Python ``math.sqrt`` variant: the
        # latter changes a handful of float32 rounding bits.
        scaled = scaled / np.sqrt(HEAD_DIMS[head])
        transformed_parts.append(scaled)

    tensor = np.concatenate(transformed_parts, axis=-1)
    if tensor.shape[-1] != INPUT_CHANNELS:
        raise RuntimeError(f"Expected {INPUT_CHANNELS} channels, found {tensor.shape[-1]}.")
    return tensor.astype(np.float32, copy=False)
