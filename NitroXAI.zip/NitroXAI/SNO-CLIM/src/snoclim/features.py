"""Notebook-parity handcrafted feature and window generation."""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np

from .constants import (
    AA_TO_INDEX,
    ACIDIC_RESIDUES,
    BASIC_RESIDUES,
    HALF_WINDOW,
    HEADS,
    HYDROPATHY,
    INPUT_CHANNELS,
    PROLINE_TAU,
)


def get_window(seq: str, pos0: int, half_window: int = HALF_WINDOW) -> str:
    """Extract a fixed-length, cysteine-centred window exactly as in the notebook."""

    seq = str(seq).upper()
    pad = "X" * half_window
    padded = pad + seq + pad
    center = pos0 + half_window
    window = padded[center - half_window : center + half_window + 1]
    expected_length = 2 * half_window + 1
    assert len(window) == expected_length, (
        f"Unexpected window length: {len(window)} != {expected_length}"
    )
    return window


def encode_window_heads(
    seq: str,
    pos0: int,
    half_window: int = HALF_WINDOW,
) -> dict[str, np.ndarray]:
    """Encode one window into the seven frozen SNO-CLIM feature heads.

    This is a direct extraction of the final notebook feature function.  In
    particular, ``X`` and unknown alphabetic residues have all-zero biochemical
    channels, while both positional channels remain active for padding.
    """

    window = get_window(seq, pos0, half_window)
    sigma = max(2.0, half_window / 3.0)
    out: dict[str, list[np.ndarray]] = {head: [] for head in HEADS}

    for index, amino_acid in enumerate(window):
        rel = index - half_window

        aa_vec = np.zeros(20, dtype=np.float32)
        if amino_acid in AA_TO_INDEX:
            aa_vec[AA_TO_INDEX[amino_acid]] = 1.0

        hydro_vec = np.array([HYDROPATHY.get(amino_acid, 0.0)], dtype=np.float32)
        acid_vec = np.array([1.0 if amino_acid in ACIDIC_RESIDUES else 0.0], dtype=np.float32)
        base_vec = np.array([1.0 if amino_acid in BASIC_RESIDUES else 0.0], dtype=np.float32)
        cys_vec = np.array([1.0 if amino_acid == "C" else 0.0], dtype=np.float32)
        pro_vec = np.array(
            [np.exp(-abs(rel) / PROLINE_TAU) if amino_acid == "P" else 0.0],
            dtype=np.float32,
        )
        dist_vec = np.array(
            [rel / max(1, half_window), np.exp(-abs(rel) / sigma)],
            dtype=np.float32,
        )

        feature_bank = {
            "aa": aa_vec,
            "hydro": hydro_vec,
            "acid": acid_vec,
            "base": base_vec,
            "cys": cys_vec,
            "pro": pro_vec,
            "dist": dist_vec,
        }
        for head in HEADS:
            out[head].append(feature_bank[head])

    return {head: np.asarray(values, dtype=np.float32) for head, values in out.items()}


def encode_windows(
    seq: str,
    positions0: Iterable[int],
    half_window: int = HALF_WINDOW,
) -> dict[str, np.ndarray]:
    """Encode multiple sites from one sequence into batched feature heads."""

    positions = list(positions0)
    values: dict[str, list[np.ndarray]] = {head: [] for head in HEADS}
    for position0 in positions:
        encoded = encode_window_heads(seq, int(position0), half_window)
        for head in HEADS:
            values[head].append(encoded[head])

    window_size = 2 * half_window + 1
    return {
        head: (
            np.asarray(values[head], dtype=np.float32)
            if values[head]
            else np.empty((0, window_size, encoded_head_dim(head)), dtype=np.float32)
        )
        for head in HEADS
    }


def encoded_head_dim(head: str) -> int:
    """Keep empty batch construction local without changing feature ordering."""

    from .constants import HEAD_DIMS

    return HEAD_DIMS[head]


def concatenate_heads(heads: dict[str, np.ndarray]) -> np.ndarray:
    """Concatenate raw feature heads in their notebook-defined channel order."""

    tensor = np.concatenate([heads[head] for head in HEADS], axis=-1).astype(np.float32, copy=False)
    if tensor.shape[-1] != INPUT_CHANNELS:
        raise RuntimeError(f"Expected {INPUT_CHANNELS} raw feature channels, got {tensor.shape[-1]}.")
    return tensor
