"""SNO-CLIM: residue-level S-nitrosylation site prediction."""

from .predictor import PredictionResult, SNOCLIMPredictor

__version__ = "0.1.1"

__all__ = ["PredictionResult", "SNOCLIMPredictor", "__version__"]
