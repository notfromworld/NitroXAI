"""Small dependency-free output helpers for CLI prediction workflows."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable, Mapping


def rows_to_csv(rows: list[Mapping[str, object]]) -> str:
    """Render records to CSV, retaining a useful schema even when empty."""

    if not rows:
        return ""
    columns = _columns(rows)
    lines: list[str] = []
    import io

    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue()


def rows_to_json(rows: list[Mapping[str, object]]) -> str:
    """Render records as readable JSON."""

    return json.dumps(rows, indent=2, allow_nan=False) + "\n"


def rows_to_table(rows: list[Mapping[str, object]]) -> str:
    """Render a compact plain-text table suitable for a terminal."""

    if not rows:
        return "No predictions generated.\n"
    columns = _columns(rows)
    rendered = [[_format_value(row.get(column)) for column in columns] for row in rows]
    widths = [
        max(len(column), *(len(record[index]) for record in rendered))
        for index, column in enumerate(columns)
    ]
    header = "  ".join(column.ljust(width) for column, width in zip(columns, widths))
    separator = "  ".join("-" * width for width in widths)
    body = [
        "  ".join(value.ljust(width) for value, width in zip(record, widths))
        for record in rendered
    ]
    return "\n".join([header, separator, *body]) + "\n"


def render_rows(rows: list[Mapping[str, object]], output_format: str) -> str:
    """Dispatch one of the documented output formats."""

    if output_format == "csv":
        return rows_to_csv(rows)
    if output_format == "json":
        return rows_to_json(rows)
    if output_format == "table":
        return rows_to_table(rows)
    raise ValueError(f"Unsupported output format: {output_format}")


def write_rows(path: str | Path, rows: list[Mapping[str, object]], output_format: str) -> None:
    """Write output without inferring semantics from the current directory."""

    output_path = Path(path).expanduser()
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(render_rows(rows, output_format), encoding="utf-8")
    except OSError as exc:
        raise OSError("Unable to write output file.") from exc


def _columns(rows: Iterable[Mapping[str, object]]) -> list[str]:
    columns: list[str] = []
    for row in rows:
        for column in row:
            if column not in columns:
                columns.append(column)
    return columns


def _format_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return repr(value)
    return str(value)
