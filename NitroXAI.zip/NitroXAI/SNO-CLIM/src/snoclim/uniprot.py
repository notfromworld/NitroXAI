"""Optional, timeout-bounded UniProt FASTA retrieval."""

from __future__ import annotations

import re
from urllib.parse import quote

import requests

from .exceptions import UniProtError
from .sequence import FastaRecord, parse_fasta_text

UNIPROT_FASTA_URL = "https://rest.uniprot.org/uniprotkb/{accession}.fasta"
_ACCESSION_RE = re.compile(r"[A-Z0-9]{1,20}")


def normalize_accession(accession: str) -> str:
    """Validate an accession sufficiently to keep it out of a URL path escape."""

    value = str(accession).strip().upper()
    if not _ACCESSION_RE.fullmatch(value):
        raise UniProtError(f"Invalid UniProt accession: {accession!r}.")
    return value


def fetch_uniprot_sequence(
    accession: str,
    *,
    timeout: float = 20.0,
    session: requests.Session | None = None,
) -> FastaRecord:
    """Fetch one sequence from UniProt's official REST FASTA endpoint.

    Network retrieval is deliberately optional; all sequence and local FASTA
    workflows remain offline.  Callers receive a concise public error rather
    than a low-level ``requests`` traceback.
    """

    normalized = normalize_accession(accession)
    url = UNIPROT_FASTA_URL.format(accession=quote(normalized, safe=""))
    client = session if session is not None else requests
    try:
        response = client.get(url, timeout=timeout)
    except requests.RequestException as exc:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        ) from exc

    if response.status_code != 200:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        )

    try:
        records = parse_fasta_text(response.text, source=f"UniProt accession {normalized}")
    except Exception as exc:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        ) from exc

    if len(records) != 1:
        raise UniProtError(
            f"Unable to retrieve UniProt accession {normalized}. "
            "Check internet connectivity and accession validity."
        )
    record = records[0]
    # Keep user-facing IDs stable even though a UniProt FASTA header has a
    # compound identifier such as sp|P04637|P53_HUMAN.
    return FastaRecord(normalized, record.description, record.sequence)
