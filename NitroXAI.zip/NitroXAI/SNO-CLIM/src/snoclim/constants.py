"""Frozen SNO-CLIM model constants verified against the final notebook."""

from __future__ import annotations

import math

WINDOW_SIZE = 61
HALF_WINDOW = 30
INPUT_CHANNELS = 27
N_FOLDS = 5
DROPOUT = 0.25
FINAL_THRESHOLD = 0.5857522487640381
MODEL_ARCHITECTURE = "snoclim_cnn_bilstm_weighted_bce"
MODEL_PARAMETER_COUNT = 154_369
DEFAULT_BATCH_SIZE = 128
IG_STEPS = 32

AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
AA_TO_INDEX = {amino_acid: index for index, amino_acid in enumerate(AA_ORDER)}

# Kyte-Doolittle values exactly as represented in the final notebook.
HYDROPATHY = {
    "A": 1.8,
    "C": 2.5,
    "D": -3.5,
    "E": -3.5,
    "F": 2.8,
    "G": -0.4,
    "H": -3.2,
    "I": 4.5,
    "K": -3.9,
    "L": 3.8,
    "M": 1.9,
    "N": -3.5,
    "P": -1.6,
    "Q": -3.5,
    "R": -4.5,
    "S": -0.8,
    "T": -0.7,
    "V": 4.2,
    "W": -0.9,
    "Y": -1.3,
    "X": 0.0,
}

ACIDIC_RESIDUES = frozenset({"D", "E"})
BASIC_RESIDUES = frozenset({"K", "R", "H"})
PROLINE_TAU = 1.0

# This exact order is both the scaler order and the model-channel order.
HEADS = ("aa", "hydro", "acid", "base", "cys", "pro", "dist")
HEAD_DIMS = {
    "aa": 20,
    "hydro": 1,
    "acid": 1,
    "base": 1,
    "cys": 1,
    "pro": 1,
    "dist": 2,
}

CHANNEL_SLICES: dict[str, slice] = {}
_start = 0
for _head in HEADS:
    _end = _start + HEAD_DIMS[_head]
    CHANNEL_SLICES[_head] = slice(_start, _end)
    _start = _end
del _start, _end, _head

assert sum(HEAD_DIMS.values()) == INPUT_CHANNELS
assert WINDOW_SIZE == 2 * HALF_WINDOW + 1


def head_scale_factor(head: str) -> float:
    """Return the frozen ``sqrt(head dimension)`` normalizer."""

    return math.sqrt(HEAD_DIMS[head])
