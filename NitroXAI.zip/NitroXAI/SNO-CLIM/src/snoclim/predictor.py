"""High-level, notebook-parity SNO-CLIM inference API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import torch

from .constants import DEFAULT_BATCH_SIZE, FINAL_THRESHOLD, HALF_WINDOW, N_FOLDS
from .ensemble import FoldArtifact, load_ensemble
from .features import encode_window_heads, encode_windows, get_window
from .preprocessing import transform_heads_with_fitted_scalers
from .sequence import (
    FastaRecord,
    cysteine_positions,
    normalize_sequence,
    read_fasta,
    records_from_sequences,
    validate_site,
)
from .uniprot import fetch_uniprot_sequence, normalize_accession
from .utils import resolve_device


@dataclass(frozen=True)
class PredictionResult:
    """One residue-level SNO-CLIM prediction."""

    protein_id: str
    position: int
    residue: str
    probability: float
    prediction: int
    threshold: float
    sequence_length: int
    window_sequence: str
    fold_probabilities: tuple[float, ...] | None = None

    @property
    def prediction_label(self) -> str:
        """Return the human-readable class corresponding to ``prediction``."""

        return "SNO" if self.prediction else "Non-SNO"

    def to_dict(
        self,
        *,
        include_fold_probabilities: bool = False,
        include_context: bool = False,
    ) -> dict[str, object]:
        """Render a stable, JSON-friendly result mapping."""

        row: dict[str, object] = {
            "protein_id": self.protein_id,
            "position": self.position,
            "residue": self.residue,
            "probability": self.probability,
            "prediction": self.prediction_label,
            "prediction_binary": self.prediction,
            "threshold": self.threshold,
        }
        if include_context:
            row["sequence_length"] = self.sequence_length
            row["window_sequence"] = self.window_sequence
        if include_fold_probabilities and self.fold_probabilities is not None:
            for fold, probability in enumerate(self.fold_probabilities, start=1):
                row[f"fold_{fold}_probability"] = probability
        return row


class SNOCLIMPredictor:
    """Load the frozen five-fold SNO-CLIM ensemble and perform inference.

    The models and their fold-specific scaler bundles are loaded exactly once
    for each predictor instance.  Input coordinates exposed by this class are
    always biological 1-based positions.
    """

    def __init__(
        self,
        device: str | torch.device = "auto",
        *,
        batch_size: int = DEFAULT_BATCH_SIZE,
        verify_artifacts: bool = True,
        uniprot_timeout: float = 20.0,
    ) -> None:
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size < 1:
            raise ValueError("batch_size must be a positive integer.")
        if uniprot_timeout <= 0:
            raise ValueError("uniprot_timeout must be positive.")
        self.device = resolve_device(device)
        self.batch_size = batch_size
        self.uniprot_timeout = float(uniprot_timeout)
        self._folds: list[FoldArtifact] = load_ensemble(
            self.device, verify_checksums=verify_artifacts
        )
        self._uniprot_cache: dict[str, FastaRecord] = {}

    @property
    def folds(self) -> tuple[FoldArtifact, ...]:
        """Expose loaded fold metadata without reloading package resources."""

        return tuple(self._folds)

    def raw_site_features(self, sequence: str, position: int) -> tuple[str, dict[str, np.ndarray]]:
        """Return an exact raw window and its unscaled feature heads for audit use."""

        cleaned = normalize_sequence(sequence)
        position0 = validate_site(cleaned, position)
        return get_window(cleaned, position0), encode_window_heads(cleaned, position0)

    def predict_site(
        self,
        sequence: str,
        position: int,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> PredictionResult:
        """Predict one requested cysteine site using a 1-based position."""

        cleaned = normalize_sequence(sequence)
        position0 = validate_site(cleaned, position)
        results = self._predict_positions(
            cleaned,
            [position0],
            protein_id=str(protein_id),
            include_fold_probabilities=include_fold_probabilities,
        )
        return results[0]

    def predict_all_cysteines(
        self,
        sequence: str,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Scan every cysteine in a single sequence."""

        cleaned = normalize_sequence(sequence)
        positions0 = [position - 1 for position in cysteine_positions(cleaned)]
        return self._predict_positions(
            cleaned,
            positions0,
            protein_id=str(protein_id),
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_sequence(
        self,
        sequence: str,
        *,
        protein_id: str = "sequence",
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Alias for scanning all cysteines in a raw amino-acid sequence."""

        return self.predict_all_cysteines(
            sequence,
            protein_id=protein_id,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_fasta(
        self,
        fasta_path: str,
        *,
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Predict all cysteines from every record in a local FASTA file."""

        records = read_fasta(fasta_path)
        return self._predict_records(records, include_fold_probabilities=include_fold_probabilities)

    def predict_uniprot(
        self,
        accession: str,
        *,
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Fetch a UniProt sequence once and scan all of its cysteines."""

        record = self._get_uniprot_record(accession)
        return self.predict_sequence(
            record.sequence,
            protein_id=record.identifier,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_uniprot_site(
        self,
        accession: str,
        position: int,
        *,
        include_fold_probabilities: bool = False,
    ) -> PredictionResult:
        """Fetch a UniProt sequence once and predict one requested cysteine."""

        record = self._get_uniprot_record(accession)
        return self.predict_site(
            record.sequence,
            position,
            protein_id=record.identifier,
            include_fold_probabilities=include_fold_probabilities,
        )

    def predict_batch(
        self,
        sequences: Iterable[tuple[str, str] | FastaRecord],
        *,
        include_fold_probabilities: bool = False,
    ) -> list[PredictionResult]:
        """Predict every cysteine in an iterable of programmatic sequence records."""

        return self._predict_records(
            records_from_sequences(sequences),
            include_fold_probabilities=include_fold_probabilities,
        )

    def explain_site(
        self,
        sequence: str,
        position: int,
        *,
        protein_id: str = "sequence",
        detailed: bool = False,
    ):
        """Run the final notebook's 32-step Integrated Gradients procedure."""

        from .interpretability import explain_site

        cleaned = normalize_sequence(sequence)
        position0 = validate_site(cleaned, position)
        return explain_site(
            folds=self._folds,
            device=self.device,
            sequence=cleaned,
            position0=position0,
            protein_id=str(protein_id),
            detailed=detailed,
        )

    def explain_uniprot_site(self, accession: str, position: int, *, detailed: bool = False):
        """Fetch a UniProt sequence and explain one cysteine prediction."""

        record = self._get_uniprot_record(accession)
        return self.explain_site(
            record.sequence,
            position,
            protein_id=record.identifier,
            detailed=detailed,
        )

    def _get_uniprot_record(self, accession: str) -> FastaRecord:
        normalized = normalize_accession(accession)
        if normalized not in self._uniprot_cache:
            self._uniprot_cache[normalized] = fetch_uniprot_sequence(
                normalized, timeout=self.uniprot_timeout
            )
        return self._uniprot_cache[normalized]

    def _predict_records(
        self,
        records: Iterable[FastaRecord],
        *,
        include_fold_probabilities: bool,
    ) -> list[PredictionResult]:
        site_metadata: list[tuple[str, str, int]] = []
        head_parts: dict[str, list[np.ndarray]] = {
            head: [] for head in ("aa", "hydro", "acid", "base", "cys", "pro", "dist")
        }
        for record in records:
            sequence = normalize_sequence(record.sequence)
            positions0 = [position - 1 for position in cysteine_positions(sequence)]
            if not positions0:
                continue
            encoded = encode_windows(sequence, positions0, HALF_WINDOW)
            for head in head_parts:
                head_parts[head].append(encoded[head])
            site_metadata.extend((record.identifier, sequence, position0) for position0 in positions0)

        if not site_metadata:
            return []
        heads = {head: np.concatenate(parts, axis=0) for head, parts in head_parts.items()}
        matrix = self._fold_probability_matrix(heads, len(site_metadata))
        ensemble_probability = matrix.mean(axis=0).astype(np.float32)
        return [
            self._make_result(
                protein_id=protein_id,
                sequence=sequence,
                position0=position0,
                probability=float(ensemble_probability[site_index]),
                fold_probabilities=(
                    tuple(float(matrix[fold, site_index]) for fold in range(N_FOLDS))
                    if include_fold_probabilities
                    else None
                ),
            )
            for site_index, (protein_id, sequence, position0) in enumerate(site_metadata)
        ]

    def _predict_positions(
        self,
        sequence: str,
        positions0: list[int],
        *,
        protein_id: str,
        include_fold_probabilities: bool,
    ) -> list[PredictionResult]:
        if not positions0:
            return []

        heads = encode_windows(sequence, positions0, HALF_WINDOW)
        matrix = self._fold_probability_matrix(heads, len(positions0))
        ensemble_probability = matrix.mean(axis=0).astype(np.float32)

        return [
            self._make_result(
                protein_id=protein_id,
                sequence=sequence,
                position0=position0,
                probability=float(ensemble_probability[site_index]),
                fold_probabilities=(
                    tuple(float(matrix[fold, site_index]) for fold in range(N_FOLDS))
                    if include_fold_probabilities
                    else None
                ),
            )
            for site_index, position0 in enumerate(positions0)
        ]

    def _fold_probability_matrix(
        self, heads: dict[str, np.ndarray], sample_count: int
    ) -> np.ndarray:
        fold_probabilities: list[np.ndarray] = []
        for artifact in self._folds:
            transformed = transform_heads_with_fitted_scalers(heads, artifact.scalers)
            fold_probabilities.append(self._run_model(artifact.model, transformed))

        matrix = np.stack(fold_probabilities, axis=0)
        if matrix.shape != (N_FOLDS, sample_count):
            raise RuntimeError(f"Unexpected fold probability matrix shape: {matrix.shape}.")
        return matrix

    def _make_result(
        self,
        *,
        protein_id: str,
        sequence: str,
        position0: int,
        probability: float,
        fold_probabilities: tuple[float, ...] | None,
    ) -> PredictionResult:
        return PredictionResult(
            protein_id=protein_id,
            position=position0 + 1,
            residue=sequence[position0],
            probability=probability,
            prediction=int(probability >= FINAL_THRESHOLD),
            threshold=FINAL_THRESHOLD,
            sequence_length=len(sequence),
            window_sequence=get_window(sequence, position0, HALF_WINDOW),
            fold_probabilities=fold_probabilities,
        )

    def _run_model(self, model: torch.nn.Module, inputs: np.ndarray) -> np.ndarray:
        """Run normal inference in the final notebook's batched eval-mode path."""

        probabilities: list[np.ndarray] = []
        model.eval()
        with torch.inference_mode():
            for start in range(0, len(inputs), self.batch_size):
                batch = torch.from_numpy(inputs[start : start + self.batch_size]).to(
                    self.device, dtype=torch.float32, non_blocking=self.device.type == "cuda"
                )
                logits = model(batch).reshape(-1)
                probability = torch.sigmoid(logits)
                probabilities.append(probability.detach().cpu().numpy().reshape(-1))
        return np.concatenate(probabilities).astype(np.float32, copy=False)
