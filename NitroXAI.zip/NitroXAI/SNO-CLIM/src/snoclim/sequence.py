"""Sequence validation, coordinate handling, and FASTA parsing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .exceptions import SequenceValidationError, SiteValidationError


@dataclass(frozen=True)
class FastaRecord:
    """A safe, minimal representation of one FASTA record."""

    identifier: str
    description: str
    sequence: str


def normalize_sequence(sequence: str) -> str:
    """Remove whitespace and uppercase a protein sequence.

    The final notebook uses ``str(seq).upper()`` and encodes unrecognised
    alphabetic residues as all-zero biochemical features.  This public
    validator preserves that inference behavior while rejecting non-alphabetic
    content such as FASTA delimiters, digits, and stop characters.
    """

    if sequence is None:
        raise SequenceValidationError("A protein sequence is required.")
    cleaned = "".join(str(sequence).split()).upper()
    if not cleaned:
        raise SequenceValidationError("Protein sequence is empty.")
    if not cleaned.isascii() or not cleaned.isalpha():
        raise SequenceValidationError(
            "Protein sequence must contain alphabetic amino-acid codes only."
        )
    return cleaned


def validate_site(sequence: str, position: int) -> int:
    """Validate a biological 1-based cysteine coordinate and return 0-based."""

    if isinstance(position, bool) or not isinstance(position, int):
        raise SiteValidationError("Position must be a 1-based integer.")
    if position < 1 or position > len(sequence):
        raise SiteValidationError(
            f"Position {position} is outside this sequence (length {len(sequence)})."
        )
    position0 = position - 1
    residue = sequence[position0]
    if residue != "C":
        raise SiteValidationError(
            f"Position {position} contains '{residue}', not cysteine (C)."
        )
    return position0


def cysteine_positions(sequence: str) -> list[int]:
    """Return all cysteine positions using biological 1-based coordinates."""

    return [index + 1 for index, residue in enumerate(sequence) if residue == "C"]


def _finalize_record(
    records: list[FastaRecord],
    identifier: str | None,
    description: str | None,
    sequence_parts: list[str],
) -> None:
    if identifier is None:
        return
    sequence = normalize_sequence("".join(sequence_parts))
    records.append(
        FastaRecord(
            identifier=identifier,
            description=description if description is not None else identifier,
            sequence=sequence,
        )
    )


def parse_fasta_text(text: str, source: str = "FASTA input") -> list[FastaRecord]:
    """Parse standard, multiline FASTA without executing header content."""

    if text is None:
        raise SequenceValidationError(f"{source} is empty.")

    records: list[FastaRecord] = []
    identifier: str | None = None
    description: str | None = None
    sequence_parts: list[str] = []

    for line_number, line in enumerate(str(text).splitlines(), start=1):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith(">"):
            _finalize_record(records, identifier, description, sequence_parts)
            description = stripped[1:].strip()
            if not description:
                raise SequenceValidationError(f"{source}: FASTA header at line {line_number} is empty.")
            identifier = description.split()[0]
            sequence_parts = []
            continue
        if identifier is None:
            raise SequenceValidationError(
                f"{source}: sequence data occurs before a FASTA header at line {line_number}."
            )
        sequence_parts.append("".join(stripped.split()))

    _finalize_record(records, identifier, description, sequence_parts)
    if not records:
        raise SequenceValidationError(f"{source} contains no FASTA records.")
    return records


def read_fasta(path: str | Path) -> list[FastaRecord]:
    """Read a local FASTA file with clear input errors."""

    fasta_path = Path(path).expanduser()
    if not fasta_path.is_file():
        raise SequenceValidationError("FASTA input path does not exist or is not a file.")
    try:
        text = fasta_path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise SequenceValidationError("FASTA input must be UTF-8 text.") from exc
    except OSError as exc:
        raise SequenceValidationError("Unable to read FASTA input file.") from exc
    return parse_fasta_text(text, source="FASTA input")


def records_from_sequences(
    sequences: Iterable[tuple[str, str] | FastaRecord],
) -> list[FastaRecord]:
    """Normalize a small programmatic batch of ``(protein_id, sequence)`` pairs."""

    records: list[FastaRecord] = []
    for item in sequences:
        if isinstance(item, FastaRecord):
            records.append(
                FastaRecord(item.identifier, item.description, normalize_sequence(item.sequence))
            )
            continue
        try:
            identifier, sequence = item
        except (TypeError, ValueError) as exc:
            raise SequenceValidationError(
                "Batch sequences must contain (protein_id, sequence) pairs."
            ) from exc
        identifier = str(identifier).strip()
        if not identifier:
            raise SequenceValidationError("A batch protein ID is empty.")
        records.append(FastaRecord(identifier, identifier, normalize_sequence(sequence)))
    return records
