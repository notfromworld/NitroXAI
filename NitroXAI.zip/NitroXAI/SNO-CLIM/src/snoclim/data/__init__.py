"""Bundled frozen SNO-CLIM model resources."""
