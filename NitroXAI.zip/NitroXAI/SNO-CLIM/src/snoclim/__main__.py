"""Module entry point for ``python -m snoclim``."""

from .cli import main


if __name__ == "__main__":  # pragma: no cover - exercised by packaging tests
    raise SystemExit(main())
