"""Loading and validation of the five frozen SNO-CLIM folds."""

from __future__ import annotations

from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import warnings

import joblib
import torch

from .config import load_asset_manifest
from .constants import (
    DROPOUT,
    HALF_WINDOW,
    INPUT_CHANNELS,
    MODEL_ARCHITECTURE,
    N_FOLDS,
    WINDOW_SIZE,
)
from .exceptions import ArtifactError
from .model import CNNBiLSTM, assert_expected_parameter_count
from .preprocessing import validate_scaler_bundle
from .utils import package_data_path, sha256_file


@dataclass
class FoldArtifact:
    """One loaded frozen fold and its matching preprocessing objects."""

    fold: int
    model: CNNBiLSTM
    scalers: dict[str, Any]
    metadata: dict[str, Any]


def _torch_load(path: Path, device: torch.device) -> dict[str, Any]:
    """Load the notebook checkpoint with safe tensor-only loading when available."""

    try:
        checkpoint = torch.load(path, map_location=device, weights_only=True)
    except TypeError:  # pragma: no cover - supports older validated PyTorch releases
        checkpoint = torch.load(path, map_location=device)
    except Exception as exc:
        raise ArtifactError(f"Unable to load frozen checkpoint '{path.name}'.") from exc
    if not isinstance(checkpoint, dict):
        raise ArtifactError(f"Frozen checkpoint '{path.name}' has an unexpected format.")
    return checkpoint


def _load_scalers(path: Path) -> dict[str, Any]:
    """Load a scaler bundle and elevate compatibility warnings to a hard error."""

    try:
        from sklearn.exceptions import InconsistentVersionWarning

        with warnings.catch_warnings():
            warnings.simplefilter("error", InconsistentVersionWarning)
            scalers = joblib.load(path)
    except Warning as exc:
        raise ArtifactError(
            f"Scaler '{path.name}' raised a serialization-version warning; "
            "use the recorded NitroXAI CV environment."
        ) from exc
    except Exception as exc:
        raise ArtifactError(f"Unable to load frozen scaler bundle '{path.name}'.") from exc
    if not isinstance(scalers, dict):
        raise ArtifactError(f"Frozen scaler bundle '{path.name}' has an unexpected format.")
    validate_scaler_bundle(scalers)
    return scalers


def verify_packaged_artifacts() -> None:
    """Check every bundled checkpoint and scaler against its source digest."""

    manifest = load_asset_manifest()
    for artifact in manifest.get("artifacts", []):
        relative_path = artifact["packaged_path"]
        expected = artifact["sha256"]
        with package_data_path(relative_path) as path:
            actual = sha256_file(path)
        if actual != expected:
            raise ArtifactError(
                f"Packaged model asset checksum mismatch for '{relative_path}'."
            )


def _validate_checkpoint_metadata(checkpoint: dict[str, Any], fold: int) -> None:
    expected = {
        "architecture": MODEL_ARCHITECTURE,
        "fold": fold,
        "window_length": WINDOW_SIZE,
        "half_window": HALF_WINDOW,
        "input_channels": INPUT_CHANNELS,
    }
    for key, value in expected.items():
        if checkpoint.get(key) != value:
            raise ArtifactError(
                f"Checkpoint fold {fold} metadata mismatch for '{key}': "
                f"expected {value!r}, found {checkpoint.get(key)!r}."
            )
    if "model_state_dict" not in checkpoint:
        raise ArtifactError(f"Checkpoint fold {fold} does not contain model_state_dict.")


def load_ensemble(device: torch.device, verify_checksums: bool = True) -> list[FoldArtifact]:
    """Load all five fold models and their corresponding saved scalers once."""

    if verify_checksums:
        verify_packaged_artifacts()

    artifacts: list[FoldArtifact] = []
    with ExitStack() as stack:
        for fold in range(1, N_FOLDS + 1):
            checkpoint_path = stack.enter_context(
                package_data_path(f"checkpoints/fold_{fold}_window61.pt")
            )
            scaler_path = stack.enter_context(
                package_data_path(f"scalers/fold_{fold}_window61_scalers.joblib")
            )
            checkpoint = _torch_load(checkpoint_path, device)
            _validate_checkpoint_metadata(checkpoint, fold)
            scalers = _load_scalers(scaler_path)

            model = CNNBiLSTM(
                in_channels=INPUT_CHANNELS,
                dropout=float(checkpoint.get("dropout", DROPOUT)),
            ).to(device)
            assert_expected_parameter_count(model)
            try:
                model.load_state_dict(checkpoint["model_state_dict"], strict=True)
            except RuntimeError as exc:
                raise ArtifactError(
                    f"Checkpoint fold {fold} has missing, unexpected, or incompatible state keys."
                ) from exc
            model.eval()
            artifacts.append(FoldArtifact(fold, model, scalers, checkpoint))

    if len(artifacts) != N_FOLDS:
        raise ArtifactError(f"Expected {N_FOLDS} frozen folds, loaded {len(artifacts)}.")
    return artifacts
