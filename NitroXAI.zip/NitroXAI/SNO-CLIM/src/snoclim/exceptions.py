"""User-facing exception types for SNO-CLIM."""


class SNOCLIMError(Exception):
    """Base class for anticipated package errors."""


class SequenceValidationError(SNOCLIMError):
    """Raised when a sequence or FASTA record is malformed."""


class SiteValidationError(SNOCLIMError):
    """Raised when a requested residue position is invalid or not cysteine."""


class ArtifactError(SNOCLIMError):
    """Raised when a frozen model asset cannot be validated or loaded."""


class UniProtError(SNOCLIMError):
    """Raised when an optional UniProt sequence request fails."""
