# Changelog

## 0.1.1 — 2026-09-01

- Packaged the frozen final SNO-CLIM Window-61 five-fold CNN–BiLSTM inference workflow.
- Preserved original checkpoints, saved fold-specific `StandardScaler` bundles, 27-channel feature construction, arithmetic probability ensemble, and OOF-derived threshold `0.5857522487640381`.
- Added Python API, CLI, FASTA and optional UniProt workflows, batch output, CPU/CUDA selection, and notebook-parity Integrated Gradients.
- Added artifact hashes, environment archive, notebook audit, parity tests, wheel, and source-distribution configuration.
