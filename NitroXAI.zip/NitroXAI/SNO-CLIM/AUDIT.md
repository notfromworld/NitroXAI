# Final notebook audit

Authoritative source: `C_SNOCLIM_REVIEW_FINAL_FIXED (Copy).ipynb`, executed with the `Python (NitroXAI CV)` kernel. The notebook contains 19 cells. Its source labels are historical and do not always match Jupyter ordinal cell numbers; this table uses the actual notebook cell number plus the meaningful source label.

| Notebook cell / definition | Package destination | Dependencies | Saved artifact dependency | Verified final behavior |
| --- | --- | --- | --- | --- |
| 1, scope markdown | Documentation | — | — | Reviewer-corrected final baseline context only. |
| 2, cohort construction | `AUDIT.md`; not runtime | pandas, Biopython, sklearn | `filtered_cysteine_summary.csv`, `clustered.fasta` | Builds 1-based/0-based labeled sites and protein-level train/dev/test partitions. It is training provenance, not inference code. |
| 3, `get_window` / `encode_window_heads` | `src/snoclim/features.py` | NumPy | — | `X` pad, 61 residues, seven heads, 27 channels, exact hydropathy/proline/distance rules. |
| 3, scaler preparation | `src/snoclim/preprocessing.py` | NumPy, scikit-learn | fold `*.joblib` | Calls saved `.transform()` per head then divides by `sqrt(head dimension)`; never fits at inference. |
| 3, `CNNBiLSTM` | `src/snoclim/model.py` | PyTorch | fold `*.pt` | CNN(27→64, k3) → CNN(64→128, k5) → BiLSTM(64) → max pool → MLP; returns a logit; 154,369 parameters. |
| 3–4, selection and earlier training helpers | Documentation only | sklearn, PyTorch | window-search CSVs | Development-only selection establishes Window 61; no retraining is packaged. |
| 5, `pwd` | Excluded | — | — | Machine-specific exploratory command. |
| 6, window-selection figure | Documentation only | pandas, matplotlib | `window_selection_cv_summary.csv` | Confirms development CV selected 61. |
| 8 (source label “Cell 5”), final training | `constants.py`, `ensemble.py`, `config.py`, `predictor.py` | PyTorch, NumPy, joblib, sklearn | five checkpoints/scalers, `FINAL_PROTOCOL.json` | Final five folds, per-fold preprocessing, sigmoid per fold, arithmetic mean of probabilities, and development-OOF threshold freezing. |
| 9 (source label “Cell 6”), artifact freeze | `reproducibility/artifact_manifest.csv`; package manifest | hashlib, PyTorch, joblib | all frozen assets | Validates threshold, dataset fingerprints, model/scaler schemas, and hashes. |
| 11 (source label “Cell 7”), figures | Documentation only | pandas, matplotlib, sklearn | frozen OOF/test tables | Generates figures from frozen predictions only; no inference behavior. |
| 12 (source label “Cell 8”), Integrated Gradients | `src/snoclim/interpretability.py` | PyTorch, NumPy | fold checkpoints/scalers | Manual zero-baseline, 32-step right-Riemann IG on pre-sigmoid logit; sums channel signed/absolute attribution per residue and averages five folds. |
| 13–15, interpretability figures/checks | Documentation only | pandas, NumPy, SciPy, matplotlib | saved IG arrays | Display normalization and post-hoc figures only. Raw IG is retained; package returns raw values. |
| 16 | Excluded | — | — | Empty cell. |
| 17–18, cross-species/homology metrics | Documentation only | pandas, NumPy, sklearn | external cohort artifacts | Evaluation analyses reuse frozen predictions and threshold; not user inference behavior. |

## Final scientific decisions verified

- The final window is 61 residues (`HALF_WINDOW = 30`), not a value selected from the interrupted earlier window sweep cell.
- Internal training coordinates are 0-based (`Pos0`), while source data and package public coordinates are biological 1-based (`Pos1`).
- The channel order is `aa`, `hydro`, `acid`, `base`, `cys`, `pro`, `dist`; dimensions are 20, 1, 1, 1, 1, 1, 2.
- Proline is not binary: it is `exp(-abs(relative_position) / 1.0)` only at `P` positions.
- Positional channels are `relative_position / 30` and `exp(-abs(relative_position) / 10)` for the final window.
- Padding uses `X`: non-positional feature channels are zero, whereas both positional channels remain active.
- Every fold uses its own saved seven-scaler bundle. No package code calls `fit` or `fit_transform` during prediction.
- Fold logits receive sigmoid independently; the five probabilities are then averaged. Logits are not averaged.
- The threshold is `0.5857522487640381`, selected from development OOF predictions with the saved near-optimal MCC/balanced SN–SP rule and frozen before test evaluation.

## Discrepancies and handling

1. The early notebook window-selection cell was interrupted in its visible output. The later final-training cell hard-checks the saved development-only window summary and freezes Window 61; the package follows that later final artifact behavior.
2. The implementation plan anticipated Captum, but the authoritative environment has no Captum and the final notebook implements Integrated Gradients manually. The package preserves that manual method rather than substituting Captum.
3. The post-hoc interpretability cells create normalized display copies for figures. The package returns raw signed and absolute IG values because the notebook explicitly keeps raw arrays unmodified.
4. Notebook cells after the frozen-human pipeline contain path-specific publication/cross-species analyses. They do not change checkpoint, feature, scaler, ensemble, threshold, or IG behavior and therefore are not runtime package dependencies.
