# SNO-CLIM 0.1.1 (10.5281/zenodo.22238589)

SNO-CLIM is a lightweight residue-level S-nitrosylation site predictor using a frozen CNN–BiLSTM model trained on handcrafted biochemical and positional features. Version 0.1.1 packages the final notebook’s existing five checkpoints, fold-specific scalers, 61-residue feature representation, ensemble rule, decision threshold, and Integrated Gradients procedure without retraining or refitting.

## Features

- Residue-level S-nitrosylation site prediction
- Raw sequence and FASTA support, including multi-record FASTA batches
- Optional UniProt accession retrieval
- Individual-cysteine prediction and all-cysteine scanning
- Batch FASTA and accession-list workflows
- Notebook-parity Integrated Gradients with residue-level attribution
- CPU inference and optional CUDA inference
- Packaged model resources that do not depend on the current working directory

## Install

Build artifacts are local only; this project does not upload to PyPI.

```bash
pip install dist/snoclim-0.1.1-py3-none-any.whl
```

The package intentionally pins the scientific runtime to the versions validated in `Python (NitroXAI CV)`: Python 3.11, PyTorch 2.13.0, NumPy 2.4.6, scikit-learn 1.9.0, SciPy 1.17.1, joblib 1.5.3, and requests 2.34.2. See `reproducibility/` for the full archived environment.

## Command line

```bash
snoclim --version
snoclim info

snoclim predict --uniprot P04637
snoclim predict --fasta protein.fasta
snoclim predict --sequence "MPEPTIDE..."
snoclim predict --uniprot P04637 --position 182

snoclim batch --fasta proteins.fasta --output predictions.csv
snoclim batch --accessions accessions.txt --output predictions.csv

snoclim explain --uniprot P04637 --position 182 --output explanation.csv
```

`predict --fasta` accepts one or more records and scans every cysteine by default. Use `--position` only with a single FASTA record. Positions are always 1-based. `--format table`, `--format csv`, and `--format json` are supported; `--fold-probabilities` adds the five fold probabilities explicitly. Every command writes to the terminal unless `--output FILE` is supplied. An output path ending in `.csv` or `.json` selects that format automatically; `--format` can still override it.

Use `--device auto` (default), `--device cpu`, or `--device cuda`. UniProt retrieval is optional and uses a bounded request timeout; raw sequence and local FASTA workflows are fully offline.

## Python API

```python
from snoclim import SNOCLIMPredictor

predictor = SNOCLIMPredictor()

all_sites = predictor.predict_sequence("MPEPTIDE...")
fasta_sites = predictor.predict_fasta("protein.fasta")
uniprot_sites = predictor.predict_uniprot("P04637")
one_site = predictor.predict_site("MPEPTIDE...", position=182)
explanation = predictor.explain_site("MPEPTIDE...", position=182)
```

`predict_sequence`, `predict_fasta`, `predict_uniprot`, and `predict_batch` scan all cysteines. `predict_site` validates that the specified 1-based position exists and is cysteine; it never shifts to a nearby residue.

## Frozen model specification

| Item | Frozen value |
| --- | --- |
| Window | target cysteine ±30 residues (61 total) |
| Input | 61 × 27 |
| Features | 20 AA one-hot; hydropathy; acidic; basic; cysteine; decayed proline; signed/decay distance |
| Model | Conv1d(27→64) → Conv1d(64→128) → bidirectional LSTM(64) → max pool → MLP |
| Trainable parameters | 154,369 |
| Ensemble | arithmetic mean of 5 fold probabilities |
| Frozen threshold | `0.5857522487640381` |

The threshold was selected from development out-of-fold predictions using the final notebook’s near-optimal MCC rule, then frozen before the independent-test evaluation. It is not recomputed from user input and is not documented as test-set derived.

## Interpretability

`snoclim explain` uses the exact final-notebook method: a zero baseline in each fold-standardized input space, 32 right-Riemann integration steps, pre-sigmoid logits, dropout/BatchNorm handling matching the notebook, and arithmetic averaging across the five folds. Raw signed and absolute residue-level values are returned; no display normalization is applied.

The final notebook does not use Captum: Captum was not installed in the authoritative environment, and its manual Integrated Gradients implementation has been preserved instead.

## Reproducibility and scope

`AUDIT.md`, `NOTEBOOK_PARITY_REPORT.md`, and `reproducibility/artifact_manifest.csv` document the mapping from notebook behavior to package code and the exact source artifact hashes. The package bundles only the frozen inference assets, not training data or evaluation data. It does not retrain, refit scalers, alter model serialization, or claim experimental validation of predictions.

## Authors and license

Authors: Soumyadeep Ray and Ganesh Bagler. Correspondence:
bagler@iiitd.ac.in. This package is distributed under the MIT license included
in `LICENSE`.
