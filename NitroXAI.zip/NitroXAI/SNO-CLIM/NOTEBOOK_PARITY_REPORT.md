# Notebook parity report

Validation used the authoritative `Python (NitroXAI CV)` interpreter and the final frozen human Window-61 artifacts.

| Check | Result |
| --- | --- |
| Raw 61-residue windows | Exact match against notebook `get_window` for positive, negative, internal, and terminal examples |
| Raw seven feature heads / 27 channels | Exact match against notebook `encode_window_heads` |
| Fold-specific transformed tensors | Exact match against notebook `transform_heads_with_fitted_scalers` |
| Model architecture / state keys | All five checkpoints load strictly; 154,369 trainable parameters |
| Fold probabilities, full independent test | Exact float32 match: maximum absolute difference `0.0` across 50,690 values |
| Ensemble probabilities, full independent test | Exact float32 match: maximum absolute difference `0.0` across 10,138 values |
| Final classifications | Identical: 10,138 / 10,138 |
| Integrated Gradients | One exact notebook-selected independent-test site compared for all 61 signed/absolute positions; passed within backend-appropriate floating-point tolerance |
| Clean installed-wheel parity | Five independent-test examples: maximum fold and ensemble probability difference `0.0`; classifications identical |

## Independent-test reproduction

The package reconstructed the final independent-test inputs from the authoritative source FASTA and frozen prediction table. With the frozen threshold `0.5857522487640381`, it reproduced:

| Metric | Package result |
| --- | --- |
| ACC | 0.7611955020714145 |
| Sensitivity | 0.7595338983050848 |
| Specificity | 0.7615757575757576 |
| MCC | 0.42965562321925305 |
| AUROC | 0.8396759116589625 |
| AUPRC | 0.5073080166001381 |
| TP / TN / FP / FN | 1434 / 6283 / 1967 / 454 |

The tiny CPU-versus-CUDA per-site variation of cuDNN/LSTM kernels is covered by backend-aware test tolerances. The authoritative full-batch CUDA parity run above was bit-identical to the saved float32 output.
