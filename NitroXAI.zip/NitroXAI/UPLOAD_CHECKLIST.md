# Upload checklist

## Before upload

- [ ] Check the title, date, authors, and related identifier in
      `ZENODO_METADATA_TEMPLATE.md` against the manuscript before submission.
- [ ] Verify the two wheel hashes from the bundle root:

  ```bash
  sha256sum -c CHECKSUMS.sha256
  ```

- [ ] Run `bash RUN_REVIEWER_SMOKE_TEST.sh` with Python 3.11 on the final
      downloaded archive, if your journal permits.

## GitHub: review-only repository

1. Create a **new empty private repository** (for example,
   `nitroxai-snoclim-review`). Do not initialize it with a README or license.
2. Copy only the contents of this `final_upload/` directory into that new
   repository; do not run `git add .` from the parent research workspace.
3. Commit and tag the exact review release as `v0.1.1-review`.
4. Add the journal editor/reviewer account using the journal's confidential
   review procedure.

## Zenodo: immutable review archive

1. Create a new Zenodo upload and upload a ZIP archive of this directory.
2. Use version `0.1.1-review`, upload type **Software**, and complete the
   metadata in `ZENODO_METADATA_TEMPLATE.md`.
3. Select **restricted access** for confidential review, or reserve the
   record until the journal tells you to publish it.
4. Put the resulting DOI (or the reserved DOI) in the manuscript only when
   the journal permits it. Ensure the GitHub release tag and Zenodo version
   describe the same immutable files.

Do not upload training notebooks, raw or processed training data, train/test
splits, cached embeddings, model-selection reports, or the parent workspace.
