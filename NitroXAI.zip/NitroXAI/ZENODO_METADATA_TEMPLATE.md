# Zenodo metadata

- **Upload type:** Software
- **Title:** NitroXAI: An Interpretable Hybrid Deep Learning Framework for Human S-Nitrosylation Site Prediction
- **Version:** `0.1.1-review`
- **Publication date:** `2026-09-02`
- **Creators:** Soumyadeep Ray; Ganesh Bagler
- **Corresponding author:** Ganesh Bagler (`bagler@iiitd.ac.in`)
- **Access right:** Restricted (confidential peer review)
- **License:** MIT
- **Related identifier: 10.5281/zenodo.22238589
- **Other identifier:** 10.5281/zenodo.20648584 (previous version 0.1.0)

## Description

This deposit provides frozen inference-only implementations of NitroXAI and
SNO-CLIM for confidential peer review. The archive includes installable Python
wheels, inference source code, five frozen model checkpoints and fold-specific
scalers per predictor, reproducibility/audit records, and a small local FASTA
smoke test. It excludes training datasets, data splits, training and
hyperparameter-optimization code, cached embeddings, and training notebooks.
The complete training pipeline and associated materials will be released after
manuscript publication, consistent with the manuscript's data/code
availability statement.
