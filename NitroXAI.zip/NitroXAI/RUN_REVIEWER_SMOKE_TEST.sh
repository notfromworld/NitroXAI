#!/usr/bin/env bash
# Install the immutable reviewer wheels in a fresh Python 3.11 environment and
# exercise local CPU inference. No training or training-data download is
# performed; NitroXAI may download its documented pretrained ESM-2 backbone.
set -euo pipefail

release_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python_bin="${PYTHON_BIN:-python3.11}"
venv_dir="${VENV_DIR:-${release_dir}/.review-venv}"
output_dir="${release_dir}/reviewer_outputs"

if ! "$python_bin" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)'; then
  echo "A Python 3.11 executable is required. Set PYTHON_BIN=/path/to/python3.11." >&2
  exit 2
fi

"$python_bin" -m venv "$venv_dir"
"$venv_dir/bin/python" -m pip install --upgrade pip
"$venv_dir/bin/python" -m pip install \
  "$release_dir/NitroXAI/dist/nitroxai-0.1.1-py3-none-any.whl" \
  "$release_dir/SNO-CLIM/dist/snoclim-0.1.1-py3-none-any.whl"
"$venv_dir/bin/python" -m pip check

mkdir -p "$output_dir"
"$venv_dir/bin/nitroxai" --version
"$venv_dir/bin/snoclim" --version
"$venv_dir/bin/snoclim" batch \
  --fasta "$release_dir/examples/reviewer_sample.fasta" \
  --device cpu \
  --output "$output_dir/snoclim_predictions.csv"
"$venv_dir/bin/nitroxai" batch \
  --fasta "$release_dir/examples/reviewer_sample.fasta" \
  --device cpu \
  --output "$output_dir/nitroxai_predictions.csv"

"$venv_dir/bin/python" - "$output_dir" <<'PY'
from __future__ import annotations

import csv
import sys
from pathlib import Path

output_dir = Path(sys.argv[1])
for filename in ("snoclim_predictions.csv", "nitroxai_predictions.csv"):
    with (output_dir / filename).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 4, f"{filename}: expected 4 output rows, found {len(rows)}"
    assert sum(row["status"] == "no_cysteines" for row in rows) == 1, (
        f"{filename}: no-cysteine control was not reported correctly"
    )
    assert sum(row["status"] == "ok" for row in rows) == 3, (
        f"{filename}: cysteine predictions were not reported correctly"
    )
print("Reviewer smoke test completed successfully.")
PY
