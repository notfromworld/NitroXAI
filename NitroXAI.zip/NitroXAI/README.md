# Reviewer test package: NitroXAI and SNO-CLIM

This archive is a **frozen inference-only release** for peer review. It lets
reviewers inspect the inference implementation and run both predictors on
their own complete protein sequences or on the supplied small FASTA file. It
does **not** contain raw data, train/validation/test splits, training scripts,
hyperparameter searches, cached embeddings, or notebooks used to train the
models. Those materials are intentionally deferred until publication, as
stated in the manuscript.

## Contents

- `NitroXAI/` — inference source, five frozen downstream checkpoints,
  fold-specific scalers, immutable wheel, and audit/reproducibility records.
- `SNO-CLIM/` — inference source, five frozen checkpoints, fold-specific
  scalers, immutable wheel, and audit/reproducibility records.
- `examples/reviewer_sample.fasta` — two small synthetic-style test records:
  one cysteine-containing sequence and one no-cysteine control.
- `RUN_REVIEWER_SMOKE_TEST.sh` — creates a clean Python 3.11 virtual
  environment, installs the two release wheels, and performs CPU predictions.
- `CHECKSUMS.sha256` — integrity hashes for the two wheels.

The wheel is the release artifact to install. The matching `src/` directories
are supplied for code inspection only; do not install from the source folders
when reproducing this release check.

## Requirements and first-run note

Use Python 3.11 (the packages declare `>=3.11,<3.12`). Internet access is
required only for dependency installation and for NitroXAI's first use: the
canonical ESM-2 150M backbone is fetched by `fair-esm` into the normal PyTorch
cache. SNO-CLIM prediction from a local FASTA is otherwise offline. CPU is
supported; a GPU is optional.

The complete validated environment is archived under
`NitroXAI/reproducibility/environment-nitroxai-cv.yml`. It is an archival
record, not necessary for the normal wheel-based smoke test.

## Run the supplied test

From this directory:

```bash
bash RUN_REVIEWER_SMOKE_TEST.sh
```

To use a particular Python 3.11 executable or virtual-environment location:

```bash
PYTHON_BIN=/path/to/python3.11 VENV_DIR=/tmp/nitroxai-review-venv \
  bash RUN_REVIEWER_SMOKE_TEST.sh
```

Successful execution writes only two CSV files under `reviewer_outputs/` and
prints `Reviewer smoke test completed successfully.`. The generated virtual
environment and output directory can be deleted afterwards.

## Manual installation

```bash
python3.11 -m venv review-venv
source review-venv/bin/activate
python -m pip install --upgrade pip
python -m pip install \
  NitroXAI/dist/nitroxai-0.1.1-py3-none-any.whl \
  SNO-CLIM/dist/snoclim-0.1.1-py3-none-any.whl
python -m pip check

snoclim batch --fasta examples/reviewer_sample.fasta \
  --device cpu --output snoclim_predictions.csv
nitroxai batch --fasta examples/reviewer_sample.fasta \
  --device cpu --output nitroxai_predictions.csv
```

The two output tables include predictions for every cysteine in the first
record and a `no_cysteines` status for the control record.

## Release scope and licensing

Both NitroXAI and SNO-CLIM are distributed under the MIT licenses included in
their respective directories. The release authors are Soumyadeep Ray and
Ganesh Bagler; correspondence: bagler@iiitd.ac.in.

For Zenodo, upload this directory as one versioned archive and retain the
version label `0.1.1`. For GitHub, publish this directory's contents in a
separate reviewer/release repository or private review branch—never the parent
research workspace, which contains the deferred training materials.
